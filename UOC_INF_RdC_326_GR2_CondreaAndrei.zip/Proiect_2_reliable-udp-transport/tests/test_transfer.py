"""Integration tests: real UDP sockets on localhost, through the damaging relay."""

import asyncio
import hashlib
import os
import random

import pytest

import rudp
from rudp import wire
from rudp.connection import State
from rudp.impair import Impairment, Relay


def run(coro, timeout=60):
    return asyncio.run(asyncio.wait_for(coro, timeout))


async def transfer(size=500_000, *, forward=None, backward=None, client_opts=None,
                   server_opts=None, client_impair=None, reader_delay=0.0):
    """Sends `size` random bytes client -> server, returns (ok, client, server)."""
    listener = await rudp.listen("127.0.0.1", 0, options=server_opts or rudp.Options(msl=0.05))
    target = listener.address
    relay = None
    if forward or backward:
        relay = Relay(target, forward or Impairment(), backward)
        target = await relay.start()
    data = os.urandom(size)
    client = await rudp.connect(*target, options=client_opts or rudp.Options(msl=0.05),
                                impair=client_impair)
    server = await listener.accept()

    async def read_all():
        got = bytearray()
        while chunk := await server.recv():
            got += chunk
            if reader_delay:
                await asyncio.sleep(reader_delay)
        await server.close()
        return bytes(got)

    reader = asyncio.create_task(read_all())
    await client.send(data)
    await client.close()
    got = await reader
    await asyncio.sleep(0.15)          # let TIME_WAIT run out
    if relay:
        relay.close()
    listener.close()
    return hashlib.sha256(got).digest() == hashlib.sha256(data).digest(), client, server


@pytest.mark.parametrize("algo", ["reno", "cubic", "fixed"])
def test_clean_transfer(algo):
    ok, client, server = run(transfer(1_000_000, client_opts=rudp.Options(cc=algo, msl=0.05)))
    assert ok
    assert client.state == State.CLOSED and server.state == State.CLOSED


def test_loss_reordering_duplication_and_corruption():
    bad = Impairment(delay=0.01, jitter=0.01, loss=0.05, duplicate=0.02, corrupt=0.01, seed=1)
    back = Impairment(delay=0.01, loss=0.03, seed=2)
    ok, client, server = run(transfer(400_000, forward=bad, backward=back))
    assert ok
    assert client.stats["retransmissions"] > 0
    assert client.stats["sack_blocks_received"] > 0
    assert server.stats["out_of_order"] > 0
    assert server.stats["duplicates_received"] > 0


def test_bottleneck_queue_causes_recovery_not_timeouts():
    link = Impairment(delay=0.02, rate_bps=8_000_000, queue_packets=30, seed=3)
    ok, client, _ = run(transfer(2_000_000, forward=link))
    assert ok
    assert client.stats["fast_recoveries"] > 0
    assert client.stats["timeouts"] <= 1


def test_only_the_lost_segment_is_resent():
    # drop exactly one data segment: Selective Repeat must resend that one and no other
    seen = {"data": 0}

    def drop_fifth_data_segment(raw):
        seg = wire.decode(raw)
        if seg.payload:
            seen["data"] += 1
            return seen["data"] == 5
        return False

    ok, client, _ = run(transfer(200_000, client_impair=drop_fifth_data_segment))
    assert ok
    assert client.stats["retransmissions"] == 1
    assert client.stats["fast_recoveries"] == 1


def test_lost_syns_are_retried():
    dropped = {"n": 0}

    def drop_two_syns(raw):
        if wire.decode(raw).has(wire.SYN) and dropped["n"] < 2:
            dropped["n"] += 1
            return True
        return False

    opts = rudp.Options(initial_rto=0.1, msl=0.05)
    ok, client, _ = run(transfer(10_000, client_opts=opts, client_impair=drop_two_syns))
    assert ok and dropped["n"] == 2


def test_sequence_numbers_wrap_around(monkeypatch):
    # start both ISNs just below 2^32 so the stream crosses zero
    monkeypatch.setattr("rudp.connection.random.getrandbits", lambda bits: (1 << 32) - 5000)
    ok, _, _ = run(transfer(300_000))
    assert ok


def test_flow_control_with_a_slow_reader():
    small = rudp.Options(recv_buffer=16 * 1024, msl=0.05)
    ok, client, _ = run(transfer(200_000, server_opts=small, reader_delay=0.002))
    assert ok
    assert client.peer_wnd <= 16 * 1024


def test_several_clients_on_one_listener():
    async def scenario():
        listener = await rudp.listen("127.0.0.1", 0, options=rudp.Options(msl=0.05))
        payloads = [os.urandom(random.randint(50_000, 150_000)) for _ in range(5)]

        async def serve():
            for _ in payloads:
                conn = await listener.accept()
                asyncio.create_task(echo(conn))

        async def echo(conn):
            while chunk := await conn.recv():
                await conn.send(chunk)
            await conn.close()

        async def client(data):
            c = await rudp.connect(*listener.address, options=rudp.Options(msl=0.05))
            await c.send(data)
            got = await c.recv_exactly(len(data))
            await c.close()
            return got == data

        server_task = asyncio.create_task(serve())
        results = await asyncio.gather(*(client(p) for p in payloads))
        server_task.cancel()
        listener.close()
        return results

    assert all(run(scenario()))


def test_reset_reaches_the_other_side():
    async def scenario():
        listener = await rudp.listen("127.0.0.1", 0)
        client = await rudp.connect(*listener.address)
        server = await listener.accept()
        client.abort()
        with pytest.raises(rudp.ConnectionReset):
            await asyncio.wait_for(server.recv(), 5)
        listener.close()

    run(scenario())


def test_unknown_connection_gets_a_reset():
    async def scenario():
        listener = await rudp.listen("127.0.0.1", 0)
        loop = asyncio.get_running_loop()
        answer = loop.create_future()

        class Probe(asyncio.DatagramProtocol):
            def datagram_received(self, data, addr):
                answer.set_result(wire.decode(data))

        transport, _ = await loop.create_datagram_endpoint(Probe, local_addr=("127.0.0.1", 0))
        transport.sendto(wire.encode(wire.Segment(1234, seq=5, ack=9, flags=wire.ACK, payload=b"?")),
                         listener.address)
        seg = await asyncio.wait_for(answer, 5)
        transport.close()
        listener.close()
        return seg

    seg = run(scenario())
    assert seg.has(wire.RST) and seg.conn_id == 1234


def test_connecting_to_nothing_times_out():
    async def scenario():
        opts = rudp.Options(initial_rto=0.05)
        with pytest.raises((rudp.ConnectionTimeout, rudp.RudpError)):
            await rudp.connect("127.0.0.1", 9, options=opts, timeout=20)

    run(scenario())
