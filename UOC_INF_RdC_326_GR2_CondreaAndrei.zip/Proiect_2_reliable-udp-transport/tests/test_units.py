"""Unit tests for the pieces that do not need a socket."""

import pytest

from rudp import cc, seqnum, wire
from rudp.ranges import RangeSet
from rudp.rtt import RttEstimator


# ---------------------------------------------------------------- wire format

def test_header_is_36_bytes():
    assert wire.HEADER_SIZE == 36


def test_encode_decode_round_trip():
    seg = wire.Segment(0xDEADBEEF, seq=4_000_000_000, ack=17, flags=wire.ACK, window=65535,
                       ts_val=123, ts_ecr=456, sack=[(10, 20), (30, 40)], payload=b"payload")
    back = wire.decode(wire.encode(seg))
    assert back == seg


def test_full_segment_fits_ipv6_minimum_mtu():
    seg = wire.Segment(1, sack=[(0, 1)] * 4, payload=b"x" * wire.MSS)
    assert len(wire.encode(seg)) + 8 + 40 <= 1280 + 48   # UDP + IPv6 headers on top of 1280


def test_every_single_bit_flip_is_rejected():
    raw = wire.encode(wire.Segment(7, seq=1, ack=2, flags=wire.ACK, payload=b"abcdef"))
    for i in range(len(raw)):
        for bit in range(8):
            bad = bytearray(raw)
            bad[i] ^= 1 << bit
            with pytest.raises(wire.DecodeError):
                wire.decode(bytes(bad))


@pytest.mark.parametrize("mangle", [
    lambda raw: raw[:20],                          # shorter than the header
    lambda raw: raw + b"extra",                    # length does not match
    lambda raw: bytes([2]) + raw[1:],              # wrong version
])
def test_malformed_datagrams_are_rejected(mangle):
    raw = wire.encode(wire.Segment(1, payload=b"hi"))
    with pytest.raises(wire.DecodeError):
        wire.decode(mangle(raw))


def test_syn_and_fin_take_one_sequence_number():
    assert wire.Segment(1, flags=wire.SYN).seg_len == 1
    assert wire.Segment(1, flags=wire.FIN | wire.ACK, payload=b"ab").seg_len == 3


# ------------------------------------------------------- sequence arithmetic

def test_comparisons_survive_wraparound():
    near_end = seqnum.MOD - 10
    after_wrap = seqnum.add(near_end, 20)
    assert after_wrap == 10
    assert seqnum.lt(near_end, after_wrap)
    assert seqnum.gt(after_wrap, near_end)
    assert seqnum.diff(after_wrap, near_end) == 20
    assert seqnum.diff(near_end, after_wrap) == -20


# ---------------------------------------------------------------- RTT / RTO

def test_rtt_follows_rfc6298():
    r = RttEstimator(min_rto=0)
    r.sample(0.1)
    assert r.srtt == pytest.approx(0.1)
    assert r.rttvar == pytest.approx(0.05)
    assert r.rto == pytest.approx(0.3)
    r.sample(0.2)
    assert r.rttvar == pytest.approx(0.75 * 0.05 + 0.25 * 0.1)
    assert r.srtt == pytest.approx(0.875 * 0.1 + 0.125 * 0.2)


def test_rto_backoff_and_limits():
    r = RttEstimator(initial_rto=1.0, min_rto=0.2, max_rto=60)
    for _ in range(10):
        r.backoff()
    assert r.rto == 60
    r.sample(0.001)
    assert r.rto == 0.2


# ------------------------------------------------------------- range set

def test_ranges_merge_and_trim():
    rs = RangeSet()
    rs.add(10, 20)
    rs.add(30, 40)
    rs.add(20, 25)          # touches the first range
    rs.add(35, 50)          # overlaps the second
    assert list(rs) == [(10, 25), (30, 50)]
    rs.remove_below(12)
    assert list(rs) == [(12, 25), (30, 50)]
    rs.remove_below(30)
    assert list(rs) == [(30, 50)]


def test_sack_blocks_put_the_latest_first():
    rs = RangeSet()
    for s in (100, 300, 500, 700, 900):
        rs.add(s, s + 50)
    blocks = rs.blocks(recent=310)
    assert blocks[0] == (300, 350)
    assert len(blocks) == 4
    assert (900, 950) in blocks


# ------------------------------------------------------- congestion control

MSS = 1000


def test_reno_slow_start_then_one_segment_per_rtt():
    c = cc.Reno(MSS)
    c.cwnd, c.ssthresh = 10 * MSS, 20 * MSS
    for _ in range(10):                     # one RTT worth of ACKs
        c.on_ack(MSS, 0, 0.1)
    assert c.cwnd == 20 * MSS               # doubled
    start = c.cwnd
    for _ in range(20):                     # another RTT, now in avoidance
        c.on_ack(MSS, 0, 0.1)
    assert start + 0.9 * MSS <= c.cwnd <= start + 1.1 * MSS


def test_reno_halves_on_loss_and_restarts_on_timeout():
    c = cc.Reno(MSS)
    c.on_loss(40 * MSS, 0)
    assert c.cwnd == c.ssthresh == 20 * MSS
    c.on_timeout(40 * MSS, 0)
    assert c.cwnd == MSS and c.ssthresh == 20 * MSS


def test_cubic_cuts_to_seventy_percent():
    c = cc.Cubic(MSS)
    c.cwnd, c.ssthresh = 100 * MSS, 50 * MSS
    c.on_loss(100 * MSS, 0)
    assert c.cwnd == 70 * MSS
    assert c.w_max == 100


def test_cubic_curve_returns_to_wmax_at_k():
    w_max = 100
    k = (w_max * 0.3 / 0.4) ** (1 / 3)
    assert cc.cubic_window(0, w_max) == pytest.approx(70)
    assert cc.cubic_window(k, w_max) == pytest.approx(w_max)
    assert cc.cubic_window(k + 1, w_max) > w_max


def test_cubic_grows_after_a_loss():
    c = cc.Cubic(MSS)
    c.cwnd, c.ssthresh = 100 * MSS, 50 * MSS
    c.on_loss(100 * MSS, 0)
    t = 0.0
    for _ in range(400):                    # ~4 s of ACKs at 100 ms RTT
        t += 0.01
        c.on_ack(MSS, t, 0.1)
    assert c.cwnd > 90 * MSS


def test_fixed_window_never_moves():
    c = cc.Fixed(MSS, window=16)
    for f in (lambda: c.on_ack(MSS, 0, 0.1), lambda: c.on_loss(10, 0), lambda: c.on_timeout(10, 0)):
        f()
    assert c.cwnd == 16 * MSS


def test_unknown_algorithm_is_refused():
    with pytest.raises(ValueError):
        cc.make("vegas")
