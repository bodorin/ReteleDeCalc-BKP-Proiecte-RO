-- Wireshark dissector for RUDP/1 (docs/SPEC.md, section 2).
--
-- Install: copy into your personal plugins folder and restart Wireshark
--   macOS / Linux: ~/.local/lib/wireshark/plugins/
--   Windows:       %APPDATA%\Wireshark\plugins\
-- RUDP is decoded on UDP port 9000; for other ports use Decode As... > RUDP.
-- Handy filters: rudp1.flags.syn == 1, rudp1.sack_count > 0, rudp1.len > 0
-- (Wireshark already has a Cisco protocol called "rudp", hence the 1)

local rudp = Proto("rudp1", "RUDP/1 reliable transport over UDP")

local f = rudp.fields
f.version   = ProtoField.uint8("rudp1.version", "Version")
f.flags     = ProtoField.uint8("rudp1.flags", "Flags", base.HEX)
f.syn       = ProtoField.bool("rudp1.flags.syn", "SYN", 8, nil, 0x01)
f.ack_flag  = ProtoField.bool("rudp1.flags.ack", "ACK", 8, nil, 0x02)
f.fin       = ProtoField.bool("rudp1.flags.fin", "FIN", 8, nil, 0x04)
f.rst       = ProtoField.bool("rudp1.flags.rst", "RST", 8, nil, 0x08)
f.sack_cnt  = ProtoField.uint8("rudp1.sack_count", "SACK count")
f.conn_id   = ProtoField.uint32("rudp1.conn_id", "Connection ID", base.HEX)
f.seq       = ProtoField.uint32("rudp1.seq", "Sequence number")
f.ack       = ProtoField.uint32("rudp1.ack", "Acknowledgment number")
f.window    = ProtoField.uint32("rudp1.window", "Receive window")
f.ts_val    = ProtoField.uint32("rudp1.ts_val", "Timestamp value (ms)")
f.ts_ecr    = ProtoField.uint32("rudp1.ts_ecr", "Timestamp echo reply (ms)")
f.len       = ProtoField.uint16("rudp1.len", "Payload length")
f.checksum  = ProtoField.uint32("rudp1.checksum", "Checksum (CRC-32)", base.HEX)
f.sack_l    = ProtoField.uint32("rudp1.sack.left", "Left edge")
f.sack_r    = ProtoField.uint32("rudp1.sack.right", "Right edge")
f.payload   = ProtoField.bytes("rudp1.payload", "Payload")

local HEADER = 36

function rudp.dissector(buf, pinfo, tree)
    if buf:len() < HEADER or buf(0, 1):uint() ~= 1 then return 0 end
    pinfo.cols.protocol = "RUDP"

    local flags = buf(1, 1):uint()
    local nsack = buf(2, 1):uint()
    local seq, ack = buf(8, 4):uint(), buf(12, 4):uint()
    local plen = buf(28, 2):uint()

    local t = tree:add(rudp, buf(0, HEADER + nsack * 8), "RUDP/1")
    t:add(f.version, buf(0, 1))
    local ft = t:add(f.flags, buf(1, 1))
    ft:add(f.syn, buf(1, 1)); ft:add(f.ack_flag, buf(1, 1)); ft:add(f.fin, buf(1, 1)); ft:add(f.rst, buf(1, 1))
    t:add(f.sack_cnt, buf(2, 1))
    t:add(f.conn_id, buf(4, 4))
    t:add(f.seq, buf(8, 4))
    t:add(f.ack, buf(12, 4))
    t:add(f.window, buf(16, 4))
    t:add(f.ts_val, buf(20, 4))
    t:add(f.ts_ecr, buf(24, 4))
    t:add(f.len, buf(28, 2))
    t:add(f.checksum, buf(32, 4))

    local sacks = {}
    for i = 0, nsack - 1 do
        local off = HEADER + i * 8
        local st = t:add(rudp, buf(off, 8), string.format("SACK block %d", i + 1))
        st:add(f.sack_l, buf(off, 4))
        st:add(f.sack_r, buf(off + 4, 4))
        -- shown relative to the ACK, so "[+1200, +4800)" reads as "holes after the ACK"
        sacks[#sacks + 1] = string.format("[+%d,+%d)", buf(off, 4):uint() - ack, buf(off + 4, 4):uint() - ack)
    end
    -- captures are often cut short (tcpdump -s), so only show what is really there
    local body = HEADER + nsack * 8
    if plen > 0 and buf:len() > body then
        t:add(f.payload, buf(body, math.min(plen, buf:len() - body)))
    end

    local names = {}
    if bit.band(flags, 0x01) ~= 0 then names[#names + 1] = "SYN" end
    if bit.band(flags, 0x02) ~= 0 then names[#names + 1] = "ACK" end
    if bit.band(flags, 0x04) ~= 0 then names[#names + 1] = "FIN" end
    if bit.band(flags, 0x08) ~= 0 then names[#names + 1] = "RST" end
    local info = string.format("[%s] seq=%u ack=%u len=%d win=%d", table.concat(names, ","), seq, ack, plen,
                               buf(16, 4):uint())
    if #sacks > 0 then info = info .. " SACK " .. table.concat(sacks, " ") end
    pinfo.cols.info = info
    return buf:len()
end

DissectorTable.get("udp.port"):add(9000, rudp)
