"""Draws every chart from results/ (needs matplotlib).

    python tools/plots.py            # English, for the README -> docs/figures
    python tools/plots.py --lang ro  # Romanian, for the report -> docs/report/figures
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from dashboard.data import fairness, trace  # noqa: E402
from rudp.cc import cubic_window  # noqa: E402

RESULTS = ROOT / "results"
COLORS = {("rudp", "reno"): "#2f6fdb", ("rudp", "cubic"): "#7c5cd6", ("rudp", "fixed"): "#8a94a3",
          ("tcp", "reno"): "#d9901a", ("tcp", "cubic"): "#1f9d74"}

TEXT = {
    "en": {
        "seg": "cwnd (segments)", "time": "time (s)", "mbps": "goodput (Mbit/s)",
        "trace": "rudp {cc} through netem: 10 Mbit/s, 40 ms RTT, 50-packet queue",
        "matrix": "Goodput on a 10 Mbit/s bottleneck, mean of 5 runs with 95% intervals",
        "path": "{rtt:.0f} ms RTT\n{loss:g}% loss", "rudp": "rudp", "tcp": "Linux TCP",
        "fair1": "Two rudp Reno flows (Jain {j:.3f})", "fair2": "rudp CUBIC vs Linux TCP CUBIC (Jain {j:.3f})",
        "flowA": "flow A", "flowB": "flow B, joins at 8 s", "cubic": "rudp CUBIC", "tcpc": "Linux TCP CUBIC",
        "theory": "CUBIC window after a loss at W_max = 100 (RFC 9438)", "wnd": "window (segments)",
        "since": "time since the loss (s)", "srtt": "smoothed RTT (ms)",
        "rtt_title": "RTT seen by rudp Reno: base 40 ms plus the queue it fills",
    },
    "ro": {
        "seg": "cwnd (segmente)", "time": "timp (s)", "mbps": "goodput (Mbit/s)",
        "trace": "rudp {cc} prin netem: 10 Mbit/s, RTT 40 ms, coadă de 50 de pachete",
        "matrix": "Goodput pe o legătură de 10 Mbit/s, media a 5 rulări, intervale de 95%",
        "path": "RTT {rtt:.0f} ms\npierdere {loss:g}%", "rudp": "rudp", "tcp": "TCP Linux",
        "fair1": "Două fluxuri rudp Reno (Jain {j:.3f})", "fair2": "rudp CUBIC vs TCP CUBIC din Linux (Jain {j:.3f})",
        "flowA": "fluxul A", "flowB": "fluxul B, intră la 8 s", "cubic": "rudp CUBIC", "tcpc": "TCP CUBIC (Linux)",
        "theory": "Fereastra CUBIC după o pierdere la W_max = 100 (RFC 9438)", "wnd": "fereastră (segmente)",
        "since": "timp de la pierdere (s)", "srtt": "RTT netezit (ms)",
        "rtt_title": "RTT văzut de rudp Reno: 40 ms de bază plus coada pe care o umple",
    },
}

plt.rcParams.update({"figure.dpi": 150, "font.size": 9.5, "axes.grid": True, "grid.alpha": 0.3,
                     "axes.spines.top": False, "axes.spines.right": False})


def traces(L, out):
    fig, axs = plt.subplots(2, 1, figsize=(7.4, 5.2), sharex=True)
    for ax, cc in zip(axs, ("reno", "cubic")):
        tr = trace(RESULTS / "traces" / f"single_{cc}.csv", max_points=6000)
        t = [p[0] for p in tr]
        ax.step(t, [p[1] for p in tr], where="post", color=COLORS[("rudp", cc)], lw=1.3, label="cwnd")
        ax.step(t, [p[2] if p[2] is not None else float("nan") for p in tr], where="post",
                color="#d9901a", ls="--", lw=1, label="ssthresh")
        ax.set_ylim(0, 125)
        ax.set_ylabel(L["seg"])
        ax.set_title(L["trace"].format(cc="Reno" if cc == "reno" else "CUBIC"), loc="left", fontsize=10)
        ax.legend(loc="upper right", fontsize=8)
    axs[-1].set_xlabel(L["time"])
    fig.tight_layout()
    fig.savefig(out / "cwnd_traces.png")
    plt.close(fig)


def rtt(L, out):
    tr = trace(RESULTS / "traces" / "single_reno.csv", max_points=6000)
    fig, ax = plt.subplots(figsize=(7.4, 2.6))
    ax.plot([p[0] for p in tr if p[3]], [p[3] for p in tr if p[3]], color="#1f9d74", lw=1)
    ax.axhline(40, color="#8a94a3", ls=":", lw=1)
    ax.set_xlabel(L["time"])
    ax.set_ylabel(L["srtt"])
    ax.set_title(L["rtt_title"], loc="left", fontsize=10)
    fig.tight_layout()
    fig.savefig(out / "rtt_trace.png")
    plt.close(fig)


def matrix(L, out):
    path = RESULTS / "matrix_summary.csv"
    if not path.exists():
        print("no matrix_summary.csv yet")
        return
    rows = list(csv.DictReader(open(path)))
    cells = sorted({(float(r["rtt_ms"]), float(r["loss"])) for r in rows})
    flows = list(COLORS)
    fig, ax = plt.subplots(figsize=(7.6, 3.8))
    width = 0.8 / len(flows)
    for i, f in enumerate(flows):
        xs, ys, es = [], [], []
        for k, (rtt_ms, loss) in enumerate(cells):
            m = [r for r in rows if (r["impl"], r["cc"]) == f
                 and float(r["rtt_ms"]) == rtt_ms and float(r["loss"]) == loss]
            if m:
                xs.append(k + (i - (len(flows) - 1) / 2) * width)
                ys.append(float(m[0]["goodput_mean"]))
                es.append(float(m[0]["ci95"]))
        label = f"{L[f[0]]} {f[1].capitalize() if f[1] != 'cubic' else 'CUBIC'}"
        ax.bar(xs, ys, width * 0.92, yerr=es, capsize=2, color=COLORS[f], label=label, error_kw={"lw": 0.8})
    ax.set_xticks(range(len(cells)))
    ax.set_xticklabels([L["path"].format(rtt=r, loss=l * 100) for r, l in cells], fontsize=8)
    ax.set_ylabel(L["mbps"])
    ax.set_title(L["matrix"], loc="left", fontsize=10)
    ax.legend(fontsize=7.5, ncol=5, loc="upper center", bbox_to_anchor=(0.5, -0.2), frameon=False)
    fig.tight_layout()
    fig.savefig(out / "goodput_matrix.png")
    plt.close(fig)


def fair(L, out):
    f = fairness(step=1.0)
    if not f:
        return
    fig, axs = plt.subplots(2, 1, figsize=(7.4, 5.0), sharey=True)
    a = f["rudp_vs_rudp"]
    axs[0].plot(a["t"], a["a"], color=COLORS[("rudp", "reno")], label=L["flowA"])
    axs[0].plot(a["t"], [v or float("nan") for v in a["b"]], color="#d9901a", label=L["flowB"])
    axs[0].set_title(L["fair1"].format(j=a["jain"]), loc="left", fontsize=10)
    b = f["rudp_vs_tcp"]
    axs[1].plot(b["t"], [v or float("nan") for v in b["rudp"]], color=COLORS[("rudp", "cubic")], label=L["cubic"])
    axs[1].plot(b["t"], [v or float("nan") for v in b["tcp"]], color=COLORS[("tcp", "cubic")], label=L["tcpc"])
    axs[1].set_title(L["fair2"].format(j=b["jain"]), loc="left", fontsize=10)
    for ax in axs:
        ax.set_ylabel("Mbit/s")
        ax.set_ylim(0, 11)
        ax.legend(fontsize=8, loc="upper right")
    axs[1].set_xlabel(L["time"])
    fig.tight_layout()
    fig.savefig(out / "fairness.png")
    plt.close(fig)


def cubic_theory(L, out):
    ts = [i / 50 for i in range(0, 501)]
    fig, ax = plt.subplots(figsize=(7.4, 2.8))
    ax.plot(ts, [cubic_window(t, 100) for t in ts], color=COLORS[("rudp", "cubic")])
    ax.axhline(100, color="#8a94a3", ls=":", lw=1)
    ax.set_xlabel(L["since"])
    ax.set_ylabel(L["wnd"])
    ax.set_title(L["theory"], loc="left", fontsize=10)
    fig.tight_layout()
    fig.savefig(out / "cubic_curve.png")
    plt.close(fig)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--lang", choices=TEXT, default="en")
    o = ap.parse_args()
    out = ROOT / ("docs/report/figures" if o.lang == "ro" else "docs/figures")
    out.mkdir(parents=True, exist_ok=True)
    L = TEXT[o.lang]
    for fn in (traces, rtt, matrix, fair, cubic_theory):
        fn(L, out)
    print("charts written to", out.relative_to(ROOT))
