"""Architecture, deployment, sequence and state diagrams for the report.

    python tools/diagrams.py            # Romanian labels -> docs/report/figures
    python tools/diagrams.py --lang en  # English -> docs/figures
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

ROOT = Path(__file__).resolve().parent.parent
BLUE, GREEN, RED, AMBER, GRAY, VIOLET = "#2f6fdb", "#1f9d74", "#d23f31", "#d9901a", "#6b7685", "#7c5cd6"

T = {
    "ro": {
        "app": "Aplicația\n(rudp send / recv, dashboard)", "api": "API: connect · listen · send · recv · close",
        "conn": "Connection (connection.py)", "fsm": "automatul de stări\nRFC 9293", "snd": "expeditor\nscoreboard SACK",
        "rcv": "receptor\nreasamblare, SACK", "rtt": "RTT / RTO\nRFC 6298", "cc": "control congestie\nfixed · Reno · CUBIC",
        "ep": "Endpoint (endpoint.py)\ndemultiplexare după (adresă, ID conexiune)", "wire": "wire.py: antet 36 B, CRC-32",
        "udp": "socket UDP (sistemul de operare)", "trace": "Tracer\nCSV / JSONL / live",
        "host": "Calculatorul gazdă (macOS / Linux / Windows)", "runner": "experiments.py\ndocker compose exec",
        "sender": "container sender\n10.77.0.10", "receiver": "container receiver\n10.77.0.20",
        "s_tools": "rudp bench\niperf3 -c", "r_tools": "rudp recv\niperf3 -s",
        "netem_s": "netem pe eth0:\n10 Mbit/s, coadă 50,\nRTT/2, pierdere", "netem_r": "netem pe eth0:\nRTT/2",
        "bridge": "rețea bridge 10.77.0.0/24", "results": "results/  →  plots.py, dashboard",
        "client": "Client", "server": "Server", "lost": "pierdut", "dup": "SACK",
        "seq_title": None,
        "st": ["CLOSED", "SYN_SENT", "SYN_RCVD", "ESTABLISHED", "FIN_WAIT_1", "FIN_WAIT_2",
               "CLOSING", "TIME_WAIT", "CLOSE_WAIT", "LAST_ACK"],
    },
    "en": {
        "app": "Application\n(rudp send / recv, dashboard)", "api": "API: connect · listen · send · recv · close",
        "conn": "Connection (connection.py)", "fsm": "state machine\nRFC 9293", "snd": "sender\nSACK scoreboard",
        "rcv": "receiver\nreassembly, SACK", "rtt": "RTT / RTO\nRFC 6298", "cc": "congestion control\nfixed · Reno · CUBIC",
        "ep": "Endpoint (endpoint.py)\ndemux by (address, connection ID)", "wire": "wire.py: 36-byte header, CRC-32",
        "udp": "UDP socket (operating system)", "trace": "Tracer\nCSV / JSONL / live",
        "host": "Host machine (macOS / Linux / Windows)", "runner": "experiments.py\ndocker compose exec",
        "sender": "sender container\n10.77.0.10", "receiver": "receiver container\n10.77.0.20",
        "s_tools": "rudp bench\niperf3 -c", "r_tools": "rudp recv\niperf3 -s",
        "netem_s": "netem on eth0:\n10 Mbit/s, 50-packet queue,\nRTT/2, loss", "netem_r": "netem on eth0:\nRTT/2",
        "bridge": "bridge network 10.77.0.0/24", "results": "results/  →  plots.py, dashboard",
        "client": "Client", "server": "Server", "lost": "lost", "dup": "SACK",
        "st": ["CLOSED", "SYN_SENT", "SYN_RCVD", "ESTABLISHED", "FIN_WAIT_1", "FIN_WAIT_2",
               "CLOSING", "TIME_WAIT", "CLOSE_WAIT", "LAST_ACK"],
    },
}


def box(ax, x, y, w, h, text, color=BLUE, fill="#eef3fc", size=8.5, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.12", fc=fill, ec=color, lw=1.3))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=size, weight="bold" if bold else None)


def arrow(ax, x1, y1, x2, y2, color="#444", text="", style="-|>", dy=0.1, ls="-", size=7.5):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle=style, color=color, lw=1.2, ls=ls))
    if text:
        ax.text((x1 + x2) / 2, (y1 + y2) / 2 + dy, text, ha="center", fontsize=size, color=color)


def canvas(w, h, xmax, ymax):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, xmax)
    ax.set_ylim(0, ymax)
    ax.axis("off")
    return fig, ax


def components(L, out):
    fig, ax = canvas(7.4, 6.2, 10, 10)
    box(ax, 0.5, 8.9, 9, 0.9, L["app"], GRAY, "#f2f3f5")
    box(ax, 0.5, 7.9, 9, 0.6, L["api"], GRAY, "#f7f8fa", size=8)
    ax.add_patch(FancyBboxPatch((0.5, 3.0), 9, 4.5, boxstyle="round,pad=0.02,rounding_size=0.15", fc="#fbfcfe", ec=BLUE, lw=1.4))
    ax.text(0.75, 7.15, L["conn"], fontsize=9, weight="bold", color=BLUE)
    box(ax, 0.8, 5.1, 2.6, 1.6, L["fsm"], VIOLET, "#f3f0fd")
    box(ax, 3.7, 5.1, 2.6, 1.6, L["snd"])
    box(ax, 6.6, 5.1, 2.6, 1.6, L["rcv"], GREEN, "#e9f5ee")
    box(ax, 2.2, 3.3, 2.6, 1.4, L["rtt"], AMBER, "#fdf3e3")
    box(ax, 5.2, 3.3, 2.6, 1.4, L["cc"], AMBER, "#fdf3e3")
    box(ax, 0.5, 1.6, 6.6, 1.0, L["ep"], GRAY, "#f2f3f5")
    box(ax, 7.4, 1.6, 2.1, 1.0, L["trace"], GREEN, "#e9f5ee", size=8)
    box(ax, 0.5, 0.75, 6.6, 0.6, L["wire"], GRAY, "#f7f8fa", size=8)
    box(ax, 0.5, 0.05, 6.6, 0.55, L["udp"], GRAY, "#eceef1", size=8)
    for x in (2.1, 5.0, 7.9):
        arrow(ax, x, 7.9, x, 7.5)
    arrow(ax, 5.0, 5.1, 4.0, 4.7)
    arrow(ax, 5.0, 5.1, 6.4, 4.7)
    arrow(ax, 3.8, 3.0, 3.8, 2.6, style="<|-|>")
    arrow(ax, 8.4, 3.0, 8.4, 2.6, GREEN)
    fig.tight_layout()
    fig.savefig(out / "arch_components.png", dpi=170)
    plt.close(fig)


def deployment(L, out):
    fig, ax = canvas(7.4, 4.4, 10, 7)
    ax.add_patch(FancyBboxPatch((0.2, 0.2), 9.6, 6.5, boxstyle="round,pad=0.02,rounding_size=0.15", fc="#fbfcfe", ec=GRAY, lw=1.2, ls="--"))
    ax.text(0.45, 6.35, L["host"], fontsize=9, weight="bold", color=GRAY)
    box(ax, 3.4, 5.1, 3.2, 0.9, L["runner"], GRAY, "#f2f3f5")
    box(ax, 0.6, 2.2, 3.4, 2.2, L["sender"] + "\n\n" + L["s_tools"], BLUE)
    box(ax, 6.0, 2.2, 3.4, 2.2, L["receiver"] + "\n\n" + L["r_tools"], GREEN, "#e9f5ee")
    box(ax, 0.6, 0.55, 3.4, 1.3, L["netem_s"], RED, "#fbeceb", size=7.5)
    box(ax, 6.0, 0.55, 3.4, 1.3, L["netem_r"], RED, "#fbeceb", size=7.5)
    arrow(ax, 4.0, 3.6, 6.0, 3.6, BLUE, "DATA", style="-|>")
    arrow(ax, 6.0, 2.9, 4.0, 2.9, GREEN, "ACK", style="-|>", dy=-0.3)
    ax.text(5.0, 2.2, L["bridge"], ha="center", fontsize=7.5, color=GRAY)
    arrow(ax, 4.2, 5.1, 2.6, 4.4, GRAY, ls="--")
    arrow(ax, 5.8, 5.1, 7.4, 4.4, GRAY, ls="--")
    ax.text(5.0, 4.75, L["results"], ha="center", fontsize=7.5, color=GRAY)
    fig.tight_layout()
    fig.savefig(out / "arch_deployment.png", dpi=170)
    plt.close(fig)


def sequence(L, out):
    msgs = [  # (from_client, label, color, lost, gap)
        (True, "SYN  seq=x", VIOLET, False), (False, "SYN+ACK  seq=y ack=x+1", VIOLET, False),
        (True, "ACK  ack=y+1", VIOLET, False),
        (True, "DATA #0", BLUE, False), (True, "DATA #1", BLUE, False), (True, "DATA #2", BLUE, True),
        (True, "DATA #3", BLUE, False), (False, "ACK 1", GREEN, False), (False, "ACK 2", GREEN, False),
        (True, "DATA #4", BLUE, False), (False, "ACK 2  " + L["dup"] + " [3,4)", GREEN, False),
        (True, "DATA #5", BLUE, False), (False, "ACK 2  " + L["dup"] + " [3,5)", GREEN, False),
        (False, "ACK 2  " + L["dup"] + " [3,6)", GREEN, False), (True, "DATA #2 (retx)", RED, False),
        (False, "ACK 6", GREEN, False),
        (True, "FIN", VIOLET, False), (False, "ACK", VIOLET, False), (False, "FIN", VIOLET, False),
        (True, "ACK", VIOLET, False),
    ]
    n = len(msgs)
    fig, ax = canvas(7.0, 9.0, 10, n + 2)
    xc, xs = 2.0, 8.0
    for x, name in ((xc, L["client"]), (xs, L["server"])):
        ax.text(x, n + 1.3, name, ha="center", fontsize=10, weight="bold")
        ax.plot([x, x], [0.3, n + 0.9], color=GRAY, lw=1.5)
    for i, (c2s, label, color, lost) in enumerate(msgs):
        y = n - i
        x1, x2 = (xc, xs) if c2s else (xs, xc)
        if lost:
            xm = x1 + (x2 - x1) * 0.55
            ax.annotate("", xy=(xm, y - 0.55), xytext=(x1, y), arrowprops=dict(arrowstyle="-", color=color, lw=1.2))
            ax.text(xm, y - 0.6, "✕ " + L["lost"], color=RED, fontsize=8, ha="left", va="center")
        else:
            ax.annotate("", xy=(x2, y - 0.6), xytext=(x1, y), arrowprops=dict(arrowstyle="-|>", color=color, lw=1.2))
        ax.text((x1 + x2) / 2, y - 0.12, label, ha="center", fontsize=7.5, color=color,
                bbox=dict(fc="white", ec="none", pad=0.5))
    fig.tight_layout()
    fig.savefig(out / "seq_connection.png", dpi=170)
    plt.close(fig)


def states(L, out):
    pos = {"CLOSED": (5, 9.2), "SYN_SENT": (2, 7.6), "SYN_RCVD": (8, 7.6), "ESTABLISHED": (5, 6.0),
           "FIN_WAIT_1": (2, 4.4), "CLOSE_WAIT": (8, 4.4), "FIN_WAIT_2": (0.9, 2.6), "CLOSING": (3.4, 2.6),
           "LAST_ACK": (8, 2.6), "TIME_WAIT": (2, 0.8), "CLOSED ": (8, 0.8)}
    edges = [("CLOSED", "SYN_SENT", "connect / SYN"), ("CLOSED", "SYN_RCVD", "SYN / SYN+ACK"),
             ("SYN_SENT", "ESTABLISHED", "SYN+ACK / ACK"), ("SYN_RCVD", "ESTABLISHED", "ACK"),
             ("ESTABLISHED", "FIN_WAIT_1", "close / FIN"), ("ESTABLISHED", "CLOSE_WAIT", "FIN / ACK"),
             ("FIN_WAIT_1", "FIN_WAIT_2", "ACK"), ("FIN_WAIT_1", "CLOSING", "FIN / ACK"),
             ("FIN_WAIT_2", "TIME_WAIT", "FIN / ACK"), ("CLOSING", "TIME_WAIT", "ACK"),
             ("CLOSE_WAIT", "LAST_ACK", "close / FIN"), ("LAST_ACK", "CLOSED ", "ACK"),
             ("TIME_WAIT", "CLOSED ", "2·MSL")]
    fig, ax = canvas(7.2, 6.4, 10, 10)
    for a, b, label in edges:
        (x1, y1), (x2, y2) = pos[a], pos[b]
        if y1 == y2:   # side by side: arrow from edge to edge
            start, end = (x1 + 0.85, y1), (x2 - 0.85, y2)
        else:
            start = (x1, y1 + (-0.32 if y2 < y1 else 0.32))
            end = (x2, y2 + (0.32 if y2 < y1 else -0.32))
        ax.annotate("", xy=end, xytext=start, arrowprops=dict(arrowstyle="-|>", color="#555", lw=1.1))
        ax.text((x1 + x2) / 2 + (0.25 if y1 != y2 else 0), (y1 + y2) / 2 + (0.18 if y1 == y2 else 0),
                label, fontsize=7, color="#555", ha="left" if y1 != y2 else "center",
                bbox=dict(fc="white", ec="none", pad=0.3))
    for name, (x, y) in pos.items():
        box(ax, x - 0.85, y - 0.32, 1.7, 0.64, name.strip(), BLUE if name != "ESTABLISHED" else GREEN,
            "#eef3fc" if name != "ESTABLISHED" else "#e9f5ee", size=7.5, bold=True)
    fig.tight_layout()
    fig.savefig(out / "state_machine.png", dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--lang", choices=T, default="ro")
    o = ap.parse_args()
    out = ROOT / ("docs/report/figures" if o.lang == "ro" else "docs/figures")
    out.mkdir(parents=True, exist_ok=True)
    for fn in (components, deployment, sequence, states):
        fn(T[o.lang], out)
    print("diagrams written to", out.relative_to(ROOT))
