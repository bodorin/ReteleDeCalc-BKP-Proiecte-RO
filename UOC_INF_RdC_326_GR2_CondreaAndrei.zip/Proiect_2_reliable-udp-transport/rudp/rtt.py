"""SRTT, RTTVAR and RTO as in RFC 6298 (times in seconds)."""


class RttEstimator:
    ALPHA = 1 / 8
    BETA = 1 / 4
    K = 4
    GRANULARITY = 0.001

    def __init__(self, initial_rto: float = 1.0, min_rto: float = 0.2, max_rto: float = 60.0):
        self.srtt: float | None = None
        self.rttvar = 0.0
        self.min_rtt = float("inf")
        self.latest = 0.0
        self.min_rto = min_rto
        self.max_rto = max_rto
        self.rto = initial_rto
        self.backoffs = 0

    def sample(self, r: float) -> None:
        if r <= 0:
            return
        self.latest = r
        self.min_rtt = min(self.min_rtt, r)
        if self.srtt is None:
            self.srtt = r
            self.rttvar = r / 2
        else:
            # rttvar first: it uses the old srtt (RFC 6298, 2.3)
            self.rttvar = (1 - self.BETA) * self.rttvar + self.BETA * abs(self.srtt - r)
            self.srtt = (1 - self.ALPHA) * self.srtt + self.ALPHA * r
        self.backoffs = 0
        self.rto = self._clamp(self.srtt + max(self.GRANULARITY, self.K * self.rttvar))

    def backoff(self) -> None:
        self.backoffs += 1
        self.rto = self._clamp(self.rto * 2)

    def _clamp(self, x: float) -> float:
        return max(self.min_rto, min(self.max_rto, x))
