"""Command line: send and receive files, or benchmark a path.

  rudp recv --listen 0.0.0.0:9000 --out received/
  rudp send photo.jpg 192.168.1.20:9000 --cc cubic --trace trace.csv
  rudp bench 192.168.1.20:9000 --size 20M --cc reno --json
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys

from . import transfer
from .cc import ALGORITHMS
from .connection import Options
from .endpoint import connect, listen
from .trace import Tracer


def host_port(text: str) -> tuple[str, int]:
    host, _, port = text.rpartition(":")
    return host or "0.0.0.0", int(port)


def size_arg(text: str) -> int:
    units = {"K": 1 << 10, "M": 1 << 20, "G": 1 << 30}
    if text[-1].upper() in units:
        return int(float(text[:-1]) * units[text[-1].upper()])
    return int(text)


def options(a) -> Options:
    return Options(cc=a.cc, fixed_window=a.window)


def say(a, text: str) -> None:
    if not getattr(a, "json", False):
        print(text, file=sys.stderr)


async def cmd_recv(a) -> None:
    tracer = Tracer(a.trace) if a.trace else None
    listener = await listen(*host_port(a.listen), options=Options(), tracer=tracer)
    say(a, f"listening on {listener.address[0]}:{listener.address[1]}")
    try:
        while True:
            conn = await listener.accept()
            say(a, f"connection from {conn.peer[0]}:{conn.peer[1]}")
            try:
                r = await transfer.receive_file(conn, None if a.discard else a.out)
            except Exception as e:  # one broken transfer should not stop the server
                say(a, f"  failed: {e}")
                continue
            mbps = r["bytes"] * 8 / r["seconds"] / 1e6 if r["seconds"] else 0
            say(a, f"  {r['name']}: {r['bytes']} bytes in {r['seconds']:.2f} s ({mbps:.1f} Mbit/s)")
            if a.json:
                print(json.dumps(r), flush=True)
            if a.once:
                break
    finally:
        listener.close()
        if tracer:
            tracer.close()


async def run_sender(a, coro_factory) -> None:
    tracer = Tracer(a.trace, a.trace_interval) if a.trace else None
    conn = await connect(*host_port(a.target), options=options(a), tracer=tracer)
    say(a, f"connected, cc={a.cc}")
    try:
        result = await coro_factory(conn)
    finally:
        if tracer:
            tracer.close()
    if a.json:
        print(json.dumps(result), flush=True)
    else:
        print(f"{result['bytes']} bytes in {result['seconds']:.2f} s, "
              f"{result['goodput_mbps']:.2f} Mbit/s, {result['retransmissions']} retransmissions, "
              f"{result['timeouts']} timeouts, verified by SHA-256")


async def cmd_send(a) -> None:
    await run_sender(a, lambda conn: transfer.send_file(conn, a.file))


async def cmd_bench(a) -> None:
    await run_sender(a, lambda conn: transfer.send_random(conn, a.size, a.seed))


def main(argv=None) -> None:
    p = argparse.ArgumentParser(prog="rudp", description="Reliable transfer over UDP")
    sub = p.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("recv", help="receive files")
    r.add_argument("--listen", default="0.0.0.0:9000")
    r.add_argument("--out", default="received")
    r.add_argument("--discard", action="store_true", help="hash and drop the data (benchmarks)")
    r.add_argument("--once", action="store_true", help="exit after one transfer")
    r.add_argument("--trace")
    r.add_argument("--json", action="store_true")
    r.set_defaults(func=cmd_recv)

    for name, fn, extra in (("send", cmd_send, "file"), ("bench", cmd_bench, None)):
        s = sub.add_parser(name, help="send a file" if extra else "send random data and measure")
        if extra:
            s.add_argument("file")
        s.add_argument("target", help="host:port")
        s.add_argument("--cc", choices=sorted(ALGORITHMS), default="reno")
        s.add_argument("--window", type=int, default=32, help="segments, for --cc fixed")
        s.add_argument("--trace", help="write cwnd/RTT samples to a .jsonl or .csv file")
        s.add_argument("--trace-interval", type=float, default=0.0, help="min seconds between ACK samples")
        s.add_argument("--json", action="store_true", help="print the result as JSON")
        if not extra:
            s.add_argument("--size", type=size_arg, default=10 << 20)
            s.add_argument("--seed", type=int, default=0)
        s.set_defaults(func=fn)

    a = p.parse_args(argv)
    try:
        asyncio.run(a.func(a))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
