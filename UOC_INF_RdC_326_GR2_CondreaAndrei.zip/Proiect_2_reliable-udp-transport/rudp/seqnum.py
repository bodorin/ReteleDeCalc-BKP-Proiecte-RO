"""32-bit sequence number arithmetic (RFC 1982).

Sequence numbers wrap around, so "a < b" means "a comes before b by less than
half the space". A connection that starts near 2^32 must keep working.
"""

MOD = 1 << 32
HALF = 1 << 31


def add(a: int, n: int) -> int:
    return (a + n) % MOD


def diff(a: int, b: int) -> int:
    """Signed distance from b to a: positive when a is ahead of b."""
    d = (a - b) % MOD
    return d - MOD if d >= HALF else d


def lt(a: int, b: int) -> bool:
    return diff(a, b) < 0


def le(a: int, b: int) -> bool:
    return diff(a, b) <= 0


def gt(a: int, b: int) -> bool:
    return diff(a, b) > 0


def ge(a: int, b: int) -> bool:
    return diff(a, b) >= 0
