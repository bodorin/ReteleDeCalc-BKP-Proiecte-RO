"""File transfer on top of an RUDP connection.

The sender writes a small header, then the file. When the receiver has it all,
it answers with the SHA-256 of what it got, so both ends know the copy is exact.

    header:  "RUDPFILE" | name length (u16) | name (utf-8) | size (u64)
    reply:   SHA-256 of the received bytes (32 bytes)
"""

from __future__ import annotations

import hashlib
import os
import struct
import time
from pathlib import Path

from .connection import Connection

MAGIC = b"RUDPFILE"
CHUNK = 256 * 1024


class TransferFailed(Exception):
    pass


def _random_source(size: int, seed: int = 0):
    """Deterministic pseudo-random bytes, so benchmarks need no file on disk."""
    block = hashlib.sha256(str(seed).encode()).digest() * (CHUNK // 32)
    left = size
    while left:
        n = min(left, CHUNK)
        yield block[:n]
        left -= n


async def send_stream(conn: Connection, name: str, size: int, chunks) -> dict:
    t0 = time.perf_counter()
    raw = name.encode()
    await conn.send(MAGIC + struct.pack("!H", len(raw)) + raw + struct.pack("!Q", size))
    digest = hashlib.sha256()
    for chunk in chunks:
        digest.update(chunk)
        await conn.send(chunk)
    remote = await conn.recv_exactly(32)
    elapsed = time.perf_counter() - t0
    await conn.close()
    verified = remote == digest.digest()
    if not verified:
        raise TransferFailed("the receiver's SHA-256 does not match")
    return summary(conn, size, elapsed, verified=True, sha256=digest.hexdigest())


async def send_file(conn: Connection, path: str | os.PathLike) -> dict:
    p = Path(path)
    size = p.stat().st_size

    def chunks():
        with open(p, "rb") as f:
            while chunk := f.read(CHUNK):
                yield chunk

    return await send_stream(conn, p.name, size, chunks())


async def send_random(conn: Connection, size: int, seed: int = 0) -> dict:
    return await send_stream(conn, f"random-{size}.bin", size, _random_source(size, seed))


async def receive_file(conn: Connection, out_dir: str | os.PathLike | None) -> dict:
    """Receives one file. With out_dir=None the bytes are hashed and thrown away."""
    t0 = time.perf_counter()
    magic = await conn.recv_exactly(len(MAGIC))
    if magic != MAGIC:
        conn.abort()
        raise TransferFailed("not an RUDP file transfer")
    (name_len,) = struct.unpack("!H", await conn.recv_exactly(2))
    name = Path((await conn.recv_exactly(name_len)).decode(errors="replace")).name or "file.bin"
    (size,) = struct.unpack("!Q", await conn.recv_exactly(8))

    digest = hashlib.sha256()
    out = None
    if out_dir is not None:
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        out = open(Path(out_dir) / name, "wb")
    left = size
    try:
        while left:
            chunk = await conn.recv(min(left, CHUNK))
            if not chunk:
                raise TransferFailed(f"connection closed with {left} bytes missing")
            digest.update(chunk)
            if out:
                out.write(chunk)
            left -= len(chunk)
    finally:
        if out:
            out.close()
    await conn.send(digest.digest())
    while await conn.recv():        # wait for the sender's FIN
        pass
    await conn.close()
    return {"name": name, "bytes": size, "seconds": time.perf_counter() - t0,
            "sha256": digest.hexdigest()}


def summary(conn: Connection, size: int, elapsed: float, **extra) -> dict:
    info = conn.info()
    return {
        "bytes": size,
        "seconds": round(elapsed, 4),
        "goodput_mbps": round(size * 8 / elapsed / 1e6, 3) if elapsed else 0,
        "cc": info["cc"],
        "retransmissions": info["retransmissions"],
        "fast_recoveries": info["fast_recoveries"],
        "timeouts": info["timeouts"],
        "segments_sent": info["segments_sent"],
        "srtt_ms": round(info["srtt"] * 1000, 2) if info["srtt"] else None,
        "min_rtt_ms": round(info["min_rtt"] * 1000, 2) if info["min_rtt"] != float("inf") else None,
        **extra,
    }
