"""Segment encoding and decoding. The layout is section 2 of docs/SPEC.md."""

from __future__ import annotations

import struct
import zlib
from dataclasses import dataclass, field

VERSION = 1
MSS = 1200
MAX_SACK_BLOCKS = 4

SYN, ACK, FIN, RST = 0x01, 0x02, 0x04, 0x08
_KNOWN_FLAGS = SYN | ACK | FIN | RST

HEADER = struct.Struct("!BBBBIIIIIIHHI")
HEADER_SIZE = HEADER.size  # 36
SACK_BLOCK = struct.Struct("!II")
_CHECKSUM_OFFSET = HEADER_SIZE - 4


class DecodeError(ValueError):
    """The datagram is not a valid segment and has to be dropped."""


@dataclass
class Segment:
    conn_id: int
    seq: int = 0
    ack: int = 0
    flags: int = 0
    window: int = 0
    ts_val: int = 0
    ts_ecr: int = 0
    sack: list[tuple[int, int]] = field(default_factory=list)
    payload: bytes = b""

    def has(self, flag: int) -> bool:
        return bool(self.flags & flag)

    @property
    def seg_len(self) -> int:
        """Sequence space this segment uses: payload, plus one for SYN and for FIN."""
        return len(self.payload) + (1 if self.flags & SYN else 0) + (1 if self.flags & FIN else 0)

    def describe(self) -> str:
        names = [n for n, f in (("SYN", SYN), ("ACK", ACK), ("FIN", FIN), ("RST", RST)) if self.flags & f]
        return f"{'|'.join(names) or '-'} seq={self.seq} ack={self.ack} len={len(self.payload)}"


def encode(seg: Segment) -> bytes:
    if len(seg.payload) > 0xFFFF:
        raise ValueError("payload too large")
    sack = seg.sack[:MAX_SACK_BLOCKS]
    head = HEADER.pack(VERSION, seg.flags, len(sack), 0, seg.conn_id, seg.seq, seg.ack,
                       seg.window, seg.ts_val, seg.ts_ecr, len(seg.payload), 0, 0)
    body = b"".join(SACK_BLOCK.pack(left, right) for left, right in sack) + seg.payload
    crc = zlib.crc32(head + body)
    return head[:_CHECKSUM_OFFSET] + crc.to_bytes(4, "big") + body


def decode(data: bytes) -> Segment:
    if len(data) < HEADER_SIZE:
        raise DecodeError("shorter than the header")
    (version, flags, n_sack, _, conn_id, seq, ack, window, ts_val, ts_ecr,
     length, _, crc) = HEADER.unpack_from(data)
    if version != VERSION:
        raise DecodeError(f"unknown version {version}")
    if flags & ~_KNOWN_FLAGS:
        raise DecodeError("unknown flag bits")
    if n_sack > MAX_SACK_BLOCKS:
        raise DecodeError("too many SACK blocks")
    if len(data) != HEADER_SIZE + n_sack * SACK_BLOCK.size + length:
        raise DecodeError("length fields do not match the datagram")
    zeroed = data[:_CHECKSUM_OFFSET] + b"\0\0\0\0" + data[HEADER_SIZE:]
    if zlib.crc32(zeroed) != crc:
        raise DecodeError("bad checksum")
    sack = [SACK_BLOCK.unpack_from(data, HEADER_SIZE + i * SACK_BLOCK.size) for i in range(n_sack)]
    payload = data[HEADER_SIZE + n_sack * SACK_BLOCK.size:]
    return Segment(conn_id, seq, ack, flags, window, ts_val, ts_ecr, sack, bytes(payload))
