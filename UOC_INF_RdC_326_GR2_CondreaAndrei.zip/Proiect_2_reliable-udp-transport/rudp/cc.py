"""Congestion controllers. Windows are in bytes; see section 6 of docs/SPEC.md.

The connection calls on_ack() for every new ACK outside recovery, on_loss()
once per recovery episode, and on_timeout() when the RTO fires.
"""

from __future__ import annotations

from .wire import MSS

INITIAL_WINDOW = 10 * MSS  # RFC 6928


class Controller:
    name = "base"

    def __init__(self, mss: int = MSS):
        self.mss = mss
        self.cwnd = INITIAL_WINDOW
        self.ssthresh = float("inf")

    @property
    def in_slow_start(self) -> bool:
        return self.cwnd < self.ssthresh

    def on_ack(self, acked: int, now: float, srtt: float | None) -> None:
        pass

    def on_loss(self, pipe: int, now: float) -> None:
        pass

    def on_timeout(self, pipe: int, now: float) -> None:
        pass


class Fixed(Controller):
    """A constant window, like Go-Back-N or Selective Repeat from the textbook."""

    name = "fixed"

    def __init__(self, mss: int = MSS, window: int = 32):
        super().__init__(mss)
        self.cwnd = window * mss


class Reno(Controller):
    """RFC 5681 with appropriate byte counting (RFC 3465, L = 2)."""

    name = "reno"

    def on_ack(self, acked, now, srtt):
        if self.in_slow_start:
            self.cwnd += min(acked, 2 * self.mss)
        else:
            self.cwnd += max(1, self.mss * acked // self.cwnd)

    def on_loss(self, pipe, now):
        self.ssthresh = max(pipe // 2, 2 * self.mss)
        self.cwnd = self.ssthresh

    def on_timeout(self, pipe, now):
        self.ssthresh = max(pipe // 2, 2 * self.mss)
        self.cwnd = self.mss


class Cubic(Controller):
    """RFC 9438. The window follows a cubic in the time since the last loss,
    so it climbs back fast after a cut and slows down near the old maximum."""

    name = "cubic"
    C = 0.4
    BETA = 0.7

    def __init__(self, mss: int = MSS):
        super().__init__(mss)
        self.w_max = 0.0          # in segments
        self.k = 0.0
        self.epoch = None         # start of the current congestion avoidance epoch
        self.w_est = 0.0          # Reno-friendly estimate, in segments

    def _start_epoch(self, now):
        self.epoch = now
        cwnd_seg = self.cwnd / self.mss
        if self.w_max < cwnd_seg:
            self.k = 0.0
            self.w_max = cwnd_seg
        else:
            self.k = ((self.w_max - cwnd_seg) / self.C) ** (1 / 3)
        self.w_est = cwnd_seg

    def on_ack(self, acked, now, srtt):
        if self.in_slow_start:
            self.cwnd += min(acked, 2 * self.mss)
            return
        if self.epoch is None:
            self._start_epoch(now)
        rtt = srtt or 0.1
        cwnd_seg = self.cwnd / self.mss
        t = now - self.epoch
        target = self.C * (t + rtt - self.k) ** 3 + self.w_max
        # Reno-friendly region (RFC 9438, 4.3)
        alpha = 3 * (1 - self.BETA) / (1 + self.BETA)
        self.w_est += alpha * (acked / self.mss) / cwnd_seg
        target = max(target, self.w_est)
        if target > cwnd_seg:
            # grow by (target - cwnd) / cwnd per acked segment, at most 50% per RTT
            inc = min(target - cwnd_seg, cwnd_seg / 2) / cwnd_seg * (acked / self.mss)
            self.cwnd += max(1, int(inc * self.mss))

    def on_loss(self, pipe, now):
        cwnd_seg = self.cwnd / self.mss
        # fast convergence: give up some room to newer flows
        self.w_max = cwnd_seg * (1 + self.BETA) / 2 if cwnd_seg < self.w_max else cwnd_seg
        self.cwnd = max(int(self.cwnd * self.BETA), 2 * self.mss)
        self.ssthresh = self.cwnd
        self.epoch = None

    def on_timeout(self, pipe, now):
        self.ssthresh = max(int(self.cwnd * self.BETA), 2 * self.mss)
        self.cwnd = self.mss
        self.w_max = 0.0
        self.epoch = None


ALGORITHMS = {"fixed": Fixed, "reno": Reno, "cubic": Cubic}


def make(name: str, mss: int = MSS, **kw) -> Controller:
    try:
        cls = ALGORITHMS[name]
    except KeyError:
        raise ValueError(f"unknown congestion control {name!r}, pick one of {sorted(ALGORITHMS)}") from None
    return cls(mss, **kw)


def cubic_window(t: float, w_max: float, beta: float = 0.7, c: float = 0.4) -> float:
    """W(t) from RFC 9438, in segments. Used by the tests and the charts."""
    k = (w_max * (1 - beta) / c) ** (1 / 3)
    return c * (t - k) ** 3 + w_max
