"""One RUDP connection: the state machine, the sender and the receiver.

Everything runs on the asyncio event loop of the endpoint that owns the
connection, so there are no locks. Internally, positions in the byte stream are
plain integers starting at 0 ("offsets"); they are turned into wrapping 32-bit
sequence numbers only at the wire. Offset o travels as ISN + 1 + o, so SYN sits
at offset -1 and the FIN takes the offset right after the last data byte.
"""

from __future__ import annotations

import asyncio
import bisect
import enum
import random
import time
from collections import OrderedDict
from dataclasses import dataclass

from . import cc as ccmod
from . import seqnum
from .ranges import RangeSet
from .rtt import RttEstimator
from .wire import ACK, FIN, MSS, RST, SYN, Segment

DUP_THRESH = 3
MAX_HANDSHAKE_RETRIES = 6
MAX_DATA_TIMEOUTS = 10


class State(enum.Enum):
    CLOSED = "CLOSED"
    LISTEN = "LISTEN"
    SYN_SENT = "SYN_SENT"
    SYN_RCVD = "SYN_RCVD"
    ESTABLISHED = "ESTABLISHED"
    FIN_WAIT_1 = "FIN_WAIT_1"
    FIN_WAIT_2 = "FIN_WAIT_2"
    CLOSING = "CLOSING"
    TIME_WAIT = "TIME_WAIT"
    CLOSE_WAIT = "CLOSE_WAIT"
    LAST_ACK = "LAST_ACK"


class ConnectionError_(ConnectionError):
    pass


class ConnectionReset(ConnectionError_):
    pass


class ConnectionTimeout(ConnectionError_, TimeoutError):
    pass


@dataclass
class Options:
    cc: str = "reno"
    fixed_window: int = 32            # segments, for cc="fixed"
    mss: int = MSS
    recv_buffer: int = 4 * 1024 * 1024
    send_buffer: int = 4 * 1024 * 1024
    msl: float = 1.0                  # TIME_WAIT lasts 2 * msl
    min_rto: float = 0.2
    initial_rto: float = 1.0


@dataclass
class SentSegment:
    start: int
    end: int                          # exclusive; a FIN segment has end = start + 1
    data: bytes
    fin: bool = False
    sent_at: float = 0.0
    tx_count: int = 0
    sacked: bool = False
    lost: bool = False
    retx_episode: int = -1            # recovery episode in which it was last resent

    @property
    def size(self) -> int:
        return self.end - self.start


class Connection:
    def __init__(self, endpoint, peer, conn_id: int, options: Options, *, tracer=None):
        self.endpoint = endpoint
        self.peer = peer
        self.conn_id = conn_id
        self.opts = options
        self.loop = asyncio.get_running_loop()
        self.state = State.CLOSED
        self.tracer = tracer
        self.t0 = self.loop.time()
        self.wall0 = time.time()

        # sequence space
        self.iss = random.getrandbits(32)
        self.irs = 0

        # sender
        self.cc = ccmod.make(options.cc, options.mss,
                             **({"window": options.fixed_window} if options.cc == "fixed" else {}))
        self.rtt = RttEstimator(options.initial_rto, options.min_rto)
        self.snd_buf = bytearray()     # written by the app, not yet cut into segments
        self.snd_una = 0
        self.snd_nxt = 0
        self.inflight: OrderedDict[int, SentSegment] = OrderedDict()
        self.peer_wnd = 64 * 1024
        self.fin_queued = False
        self.fin_off: int | None = None
        self.dupacks = 0
        self.in_recovery = False
        self.recover = 0
        self.episode = 0
        self.consecutive_timeouts = 0
        self._writable = asyncio.Event()
        self._writable.set()

        # receiver
        self.rcv_nxt = 0
        self.ooo: dict[int, bytes] = {}
        self._ooo_starts: list[int] = []
        self.ooo_ranges = RangeSet()
        self.app_buf = bytearray()
        self.peer_fin_off: int | None = None
        self.peer_fin_done = False
        self.last_peer_ts = 0
        self._readable = asyncio.Event()
        self._last_window_sent = None

        # timers
        self._rto_handle = None
        self._persist_handle = None
        self._persist_backoff = 1
        self._tw_handle = None
        self._handshake_tries = 0

        self.established = self.loop.create_future()
        self.closed = self.loop.create_future()
        self.error: Exception | None = None

        self.stats = {
            "segments_sent": 0, "segments_received": 0, "retransmissions": 0,
            "fast_recoveries": 0, "timeouts": 0, "bytes_sent": 0, "bytes_acked": 0,
            "bytes_received": 0, "dup_acks": 0, "sack_blocks_received": 0,
            "out_of_order": 0, "duplicates_received": 0, "window_probes": 0,
        }

    # ------------------------------------------------------------------ helpers

    def now(self) -> float:
        return self.loop.time() - self.t0

    def _ts(self) -> int:
        return int((self.loop.time() - self.t0) * 1000) & 0xFFFFFFFF

    def _wire_snd(self, off: int) -> int:
        return seqnum.add(self.iss, 1 + off)

    def _wire_rcv(self, off: int) -> int:
        return seqnum.add(self.irs, 1 + off)

    def _snd_off(self, wire: int) -> int:
        return self.snd_una + seqnum.diff(wire, self._wire_snd(self.snd_una))

    def _rcv_off(self, wire: int) -> int:
        return self.rcv_nxt + seqnum.diff(wire, self._wire_rcv(self.rcv_nxt))

    def _ack_wire(self) -> int:
        return self._wire_rcv(self.rcv_nxt + (1 if self.peer_fin_done else 0))

    def recv_window(self) -> int:
        used = len(self.app_buf) + sum(len(v) for v in self.ooo.values())
        return max(0, self.opts.recv_buffer - used)

    def pipe(self) -> int:
        return sum(s.size for s in self.inflight.values() if not s.sacked and not s.lost)

    def _set_state(self, st: State) -> None:
        if st != self.state:
            self.state = st
            self._trace("state")

    def _trace(self, kind: str = "ack") -> None:
        if self.tracer:
            self.tracer({
                "t": round(self.now(), 6), "wall": round(time.time(), 4), "event": kind, "conn": f"{self.conn_id:08x}",
                "state": self.state.value, "cwnd": int(self.cc.cwnd),
                "ssthresh": None if self.cc.ssthresh == float("inf") else int(self.cc.ssthresh),
                "pipe": self.pipe(), "srtt": self.rtt.srtt, "rto": self.rtt.rto,
                "rtt": self.rtt.latest, "peer_wnd": self.peer_wnd,
                "acked": self.stats["bytes_acked"], "retx": self.stats["retransmissions"],
                "recovery": self.in_recovery,
            })

    # ------------------------------------------------------------- outgoing

    def _send(self, flags: int, seq_off: int, payload: bytes = b"", *, syn: bool = False) -> None:
        sack = []
        if self.ooo_ranges:
            last = getattr(self, "_last_ooo", None)
            sack = [(self._wire_rcv(s), self._wire_rcv(e)) for s, e in self.ooo_ranges.blocks(last)]
        seq = self.iss if syn else self._wire_snd(seq_off)
        if flags & ACK or self.state not in (State.SYN_SENT, State.CLOSED):
            flags |= ACK
        if self.state == State.SYN_SENT:
            flags &= ~ACK
        win = self.recv_window()
        self._last_window_sent = win
        seg = Segment(self.conn_id, seq, self._ack_wire() if flags & ACK else 0, flags, win,
                      self._ts(), self.last_peer_ts, sack, payload)
        self.endpoint.send_segment(seg, self.peer)
        self.stats["segments_sent"] += 1

    def send_ack(self) -> None:
        self._send(ACK, self.snd_nxt)

    def _send_rst(self) -> None:
        self.endpoint.send_segment(
            Segment(self.conn_id, self._wire_snd(self.snd_nxt), self._ack_wire(), RST | ACK), self.peer)

    # ------------------------------------------------------------- handshake

    def start_active_open(self) -> None:
        self._set_state(State.SYN_SENT)
        self._send(SYN, -1, syn=True)
        self._arm_rto()

    def start_passive_open(self, syn: Segment) -> None:
        self.irs = syn.seq
        self.last_peer_ts = syn.ts_val
        self.peer_wnd = syn.window
        self._set_state(State.SYN_RCVD)
        self._send(SYN | ACK, -1, syn=True)
        self._arm_rto()

    # ------------------------------------------------------------- incoming

    def on_segment(self, seg: Segment) -> None:
        self.stats["segments_received"] += 1
        if seg.has(RST):
            self._abort(ConnectionReset("connection reset by peer"))
            return
        st = self.state

        if st == State.SYN_SENT:
            if seg.has(SYN) and seg.has(ACK) and seg.ack == seqnum.add(self.iss, 1):
                self.irs = seg.seq
                self.last_peer_ts = seg.ts_val
                self.peer_wnd = seg.window
                if seg.ts_ecr:
                    self.rtt.sample(((self._ts() - seg.ts_ecr) & 0xFFFFFFFF) / 1000)
                self._cancel_rto()
                self._set_state(State.ESTABLISHED)
                self.send_ack()
                if not self.established.done():
                    self.established.set_result(self)
                self._try_send()
            return

        if st == State.SYN_RCVD:
            if seg.has(SYN) and not seg.has(ACK):
                self._send(SYN | ACK, -1, syn=True)      # our SYN+ACK was lost
                return
            if seg.has(ACK) and seg.ack == seqnum.add(self.iss, 1):
                if seg.ts_ecr:
                    self.rtt.sample(((self._ts() - seg.ts_ecr) & 0xFFFFFFFF) / 1000)
                self._cancel_rto()
                self._set_state(State.ESTABLISHED)
                if not self.established.done():
                    self.established.set_result(self)
                st = State.ESTABLISHED
            else:
                return

        if seg.has(SYN):
            # a retransmitted SYN+ACK: our ACK got lost, say it again
            self.send_ack()
            return

        if seg.ts_val:
            self.last_peer_ts = seg.ts_val
        if seg.has(ACK):
            self._on_ack(seg)
        if self.state == State.CLOSED:
            return
        if seg.payload or seg.has(FIN):
            self._on_data(seg)
        self._try_send()
        self._maybe_trace_ack(seg)

    def _maybe_trace_ack(self, seg: Segment) -> None:
        if seg.has(ACK) and not seg.payload:
            self._trace("ack")

    # receiver side -------------------------------------------------------

    def _on_data(self, seg: Segment) -> None:
        start = self._rcv_off(seg.seq)
        data = seg.payload
        end = start + len(data)
        window_end = self.rcv_nxt + max(self.recv_window(), 1)

        if data:
            if end <= self.rcv_nxt:
                self.stats["duplicates_received"] += 1
            elif start >= window_end:
                pass                                   # beyond the window, drop it
            else:
                if start < self.rcv_nxt:               # partial overlap with what we have
                    data = data[self.rcv_nxt - start:]
                    start = self.rcv_nxt
                if start == self.rcv_nxt:
                    self._deliver(data)
                    self._drain_ooo()
                else:
                    self._store_ooo(start, data)

        if seg.has(FIN):
            self.peer_fin_off = end
        if self.peer_fin_off is not None and not self.peer_fin_done and self.rcv_nxt == self.peer_fin_off:
            self._on_peer_fin()

        self.send_ack()   # every data segment and FIN is acknowledged at once (SPEC 5.1)

    def _deliver(self, data: bytes) -> None:
        self.app_buf += data
        self.rcv_nxt += len(data)
        self.stats["bytes_received"] += len(data)
        self._readable.set()

    def _store_ooo(self, start: int, data: bytes) -> None:
        old = self.ooo.get(start)
        if old is not None and len(old) >= len(data):
            self.stats["duplicates_received"] += 1
            return
        if old is None:
            bisect.insort(self._ooo_starts, start)
        self.ooo[start] = data
        self.ooo_ranges.add(start, start + len(data))
        self._last_ooo = start
        self.stats["out_of_order"] += 1

    def _drain_ooo(self) -> None:
        while self._ooo_starts and self._ooo_starts[0] <= self.rcv_nxt:
            start = self._ooo_starts.pop(0)
            data = self.ooo.pop(start)
            if start + len(data) > self.rcv_nxt:
                self._deliver(data[self.rcv_nxt - start:])
        self.ooo_ranges.remove_below(self.rcv_nxt)

    def _on_peer_fin(self) -> None:
        self.peer_fin_done = True
        self._readable.set()
        if self.state == State.ESTABLISHED:
            self._set_state(State.CLOSE_WAIT)
        elif self.state == State.FIN_WAIT_1:
            self._set_state(State.CLOSING)
        elif self.state == State.FIN_WAIT_2:
            self._enter_time_wait()

    # sender side ---------------------------------------------------------

    def _on_ack(self, seg: Segment) -> None:
        ack = self._snd_off(seg.ack)
        if ack > self.snd_nxt:
            return                                     # acknowledges something never sent
        if ack >= self.snd_una:
            old_wnd = self.peer_wnd
            self.peer_wnd = seg.window
            if old_wnd == 0 and seg.window > 0:
                self._cancel_persist()

        newly_sacked = 0
        for left, right in seg.sack:
            self.stats["sack_blocks_received"] += 1
            lo, hi = self._snd_off(left), self._snd_off(right)
            for s in self.inflight.values():
                if not s.sacked and s.start >= lo and s.end <= hi:
                    s.sacked = True
                    s.lost = False
                    newly_sacked += 1

        if ack > self.snd_una:
            if seg.ts_ecr:
                self.rtt.sample(((self._ts() - seg.ts_ecr) & 0xFFFFFFFF) / 1000)
            acked = ack - self.snd_una
            while self.inflight:
                first = next(iter(self.inflight.values()))
                if first.end > ack:
                    break
                self.inflight.popitem(last=False)
            self.snd_una = ack
            self.stats["bytes_acked"] += acked
            self.dupacks = 0
            self.consecutive_timeouts = 0
            if self.in_recovery and self.snd_una >= self.recover:
                self.in_recovery = False
            if not self.in_recovery:
                self.cc.on_ack(acked, self.now(), self.rtt.srtt)
            self._on_fin_acked_maybe()
            self._restart_rto()
            if len(self.snd_buf) < self.opts.send_buffer:
                self._writable.set()
        elif ack == self.snd_una and self.inflight and not seg.payload and not seg.has(FIN):
            self.dupacks += 1
            self.stats["dup_acks"] += 1

        # scanning the scoreboard is O(window); only bother when something hints at a hole
        if newly_sacked or self.dupacks >= DUP_THRESH:
            self._detect_losses()

    def _detect_losses(self) -> None:
        newly_lost = False
        sacked_above = 0
        for s in reversed(self.inflight.values()):
            if s.sacked:
                sacked_above += 1
            elif not s.lost and sacked_above >= DUP_THRESH and s.retx_episode != self.episode:
                s.lost = True
                newly_lost = True
        if self.dupacks >= DUP_THRESH and self.inflight:
            first = next(iter(self.inflight.values()))
            if not first.sacked and not first.lost and first.retx_episode != self.episode:
                first.lost = True
                newly_lost = True
        if newly_lost and not self.in_recovery and self.snd_una >= self.recover:
            self.episode += 1
            self.in_recovery = True
            self.recover = self.snd_nxt
            self.stats["fast_recoveries"] += 1
            self.cc.on_loss(self.pipe() + self._lost_bytes(), self.now())
            self._trace("loss")

    def _lost_bytes(self) -> int:
        return sum(s.size for s in self.inflight.values() if s.lost)

    def _on_fin_acked_maybe(self) -> None:
        if self.fin_off is None or self.snd_una <= self.fin_off:
            return
        if self.state == State.FIN_WAIT_1:
            self._set_state(State.FIN_WAIT_2)
        elif self.state == State.CLOSING:
            self._enter_time_wait()
        elif self.state == State.LAST_ACK:
            self._finish()

    def _can_send_data(self) -> bool:
        return self.state in (State.ESTABLISHED, State.CLOSE_WAIT)

    def _try_send(self) -> None:
        if self.state in (State.CLOSED, State.SYN_SENT, State.SYN_RCVD, State.TIME_WAIT):
            return
        cwnd = self.cc.cwnd
        pipe = self.pipe()

        # 1. lost segments first (each once per episode)
        for s in self.inflight.values():
            if s.lost and not s.sacked:
                if pipe + s.size > cwnd and pipe > 0:
                    break
                self._transmit(s, retx=True)
                pipe += s.size

        # 2. new data, within both windows
        mss = self.opts.mss
        # after close() the queued data still goes out, then the FIN
        sending = self._can_send_data() or (self.fin_queued and self.fin_off is None)
        while self.snd_buf and sending:
            room_cc = cwnd - pipe
            room_fc = self.snd_una + self.peer_wnd - self.snd_nxt
            n = min(mss, len(self.snd_buf), room_fc)
            if n <= 0 or (room_cc < n and pipe > 0):
                break
            data = bytes(self.snd_buf[:n])
            del self.snd_buf[:n]
            s = SentSegment(self.snd_nxt, self.snd_nxt + n, data)
            self.inflight[s.start] = s
            self.snd_nxt += n
            self._transmit(s)
            pipe += n

        # 3. the FIN, once all data has gone out
        if self.fin_queued and self.fin_off is None and not self.snd_buf:
            s = SentSegment(self.snd_nxt, self.snd_nxt + 1, b"", fin=True)
            self.fin_off = self.snd_nxt
            self.inflight[s.start] = s
            self.snd_nxt += 1
            self._transmit(s)

        if len(self.snd_buf) < self.opts.send_buffer:
            self._writable.set()
        if self.snd_buf and self.peer_wnd == 0 and not self.inflight:
            self._arm_persist()
        if self.inflight and self._rto_handle is None:
            self._arm_rto()

    def _transmit(self, s: SentSegment, retx: bool = False) -> None:
        flags = ACK | (FIN if s.fin else 0)
        self._send(flags, s.start, s.data)
        s.sent_at = self.now()
        s.tx_count += 1
        if retx:
            s.lost = False
            s.retx_episode = self.episode
            self.stats["retransmissions"] += 1
        else:
            self.stats["bytes_sent"] += len(s.data)

    # ------------------------------------------------------------- timers

    def _arm_rto(self) -> None:
        self._cancel_rto()
        self._rto_handle = self.loop.call_later(self.rtt.rto, self._on_rto)

    def _restart_rto(self) -> None:
        if self.inflight:
            self._arm_rto()
        else:
            self._cancel_rto()

    def _cancel_rto(self) -> None:
        if self._rto_handle:
            self._rto_handle.cancel()
            self._rto_handle = None

    def _on_rto(self) -> None:
        self._rto_handle = None
        if self.state in (State.SYN_SENT, State.SYN_RCVD):
            self._handshake_tries += 1
            if self._handshake_tries > MAX_HANDSHAKE_RETRIES:
                self._abort(ConnectionTimeout("handshake timed out"))
                return
            self.rtt.backoff()
            flags = SYN if self.state == State.SYN_SENT else SYN | ACK
            self._send(flags, -1, syn=True)
            self._arm_rto()
            return
        if not self.inflight:
            return
        self.consecutive_timeouts += 1
        self.stats["timeouts"] += 1
        if self.consecutive_timeouts > MAX_DATA_TIMEOUTS:
            self._abort(ConnectionTimeout("peer stopped acknowledging"))
            return
        if self.consecutive_timeouts == 1:
            self.cc.on_timeout(self.pipe() + self._lost_bytes(), self.now())
        else:
            # a repeated timeout keeps ssthresh where the first one put it (RFC 5681, 3.1)
            self.cc.cwnd = self.opts.mss
        self.rtt.backoff()
        self.episode += 1
        for s in self.inflight.values():
            if not s.sacked:
                s.lost = True
        # after a timeout, losses of data sent before now do not cut the window again
        self.in_recovery = False
        self.recover = self.snd_nxt
        self.dupacks = 0
        self._trace("timeout")
        self._try_send()
        self._arm_rto()

    def _arm_persist(self) -> None:
        if self._persist_handle is None:
            delay = min(self.rtt.rto * self._persist_backoff, 60)
            self._persist_handle = self.loop.call_later(delay, self._on_persist)

    def _cancel_persist(self) -> None:
        if self._persist_handle:
            self._persist_handle.cancel()
            self._persist_handle = None
        self._persist_backoff = 1

    def _on_persist(self) -> None:
        self._persist_handle = None
        if self.peer_wnd > 0 or not self.snd_buf or self.state == State.CLOSED:
            self._persist_backoff = 1
            self._try_send()
            return
        # one-byte probe; the receiver answers with its current window
        data = bytes(self.snd_buf[:1])
        del self.snd_buf[:1]
        s = SentSegment(self.snd_nxt, self.snd_nxt + 1, data)
        self.inflight[s.start] = s
        self.snd_nxt += 1
        self._transmit(s)
        self.stats["window_probes"] += 1
        self._persist_backoff = min(self._persist_backoff * 2, 64)
        if self._rto_handle is None:
            self._arm_rto()

    def _enter_time_wait(self) -> None:
        self._set_state(State.TIME_WAIT)
        self._cancel_rto()
        self._cancel_persist()
        if not self.closed.done():
            self.closed.set_result(None)
        self._tw_handle = self.loop.call_later(2 * self.opts.msl, self._finish)

    def _finish(self) -> None:
        self._cancel_rto()
        self._cancel_persist()
        if self._tw_handle:
            self._tw_handle.cancel()
        self._set_state(State.CLOSED)
        self.endpoint.forget(self)
        self._readable.set()
        self._writable.set()
        if not self.closed.done():
            self.closed.set_result(None)
        if not self.established.done():
            self.established.set_exception(self.error or ConnectionError_("connection closed"))

    def _abort(self, err: Exception) -> None:
        self.error = err
        self._finish()

    # ------------------------------------------------------------- app API

    async def send(self, data: bytes) -> None:
        """Queue data for sending. Waits while the send buffer is full."""
        if self.error:
            raise self.error
        if not self._can_send_data() or self.fin_queued:
            raise ConnectionError_(f"cannot send in state {self.state.value}")
        view = memoryview(bytes(data))
        while view:
            await self._writable.wait()
            if self.error:
                raise self.error
            room = max(self.opts.send_buffer - len(self.snd_buf), 0)
            chunk = view[:max(room, self.opts.mss)]
            self.snd_buf += chunk
            view = view[len(chunk):]
            if len(self.snd_buf) >= self.opts.send_buffer:
                self._writable.clear()
            self._try_send()

    async def drain(self) -> None:
        """Waits until everything sent so far has been acknowledged."""
        while (self.snd_buf or self.inflight) and not self.error and self.state != State.CLOSED:
            fut = self.loop.create_future()
            handle = self.loop.call_later(0.01, lambda: fut.done() or fut.set_result(None))
            await fut
            handle.cancel()
        if self.error:
            raise self.error

    async def recv(self, max_bytes: int = 65536) -> bytes:
        """Returns up to max_bytes; b'' means the peer closed its side."""
        while not self.app_buf:
            if self.error:
                raise self.error
            if self.peer_fin_done or self.state == State.CLOSED:
                return b""
            self._readable.clear()
            await self._readable.wait()
        data = bytes(self.app_buf[:max_bytes])
        del self.app_buf[:max_bytes]
        # tell a stalled sender that room opened up
        if self._last_window_sent is not None and self._last_window_sent < self.opts.mss \
                and self.recv_window() >= self.opts.mss:
            self.send_ack()
        return data

    async def recv_exactly(self, n: int) -> bytes:
        out = bytearray()
        while len(out) < n:
            chunk = await self.recv(n - len(out))
            if not chunk:
                raise ConnectionError_("peer closed before sending everything")
            out += chunk
        return bytes(out)

    async def close(self, timeout: float = 30.0) -> None:
        """Sends FIN after the queued data and waits for the close to complete."""
        if self.state == State.ESTABLISHED:
            self._set_state(State.FIN_WAIT_1)
        elif self.state == State.CLOSE_WAIT:
            self._set_state(State.LAST_ACK)
        elif self.state in (State.SYN_SENT, State.SYN_RCVD):
            self._finish()
            return
        else:
            await asyncio.wait_for(asyncio.shield(self.closed), timeout)
            return
        self.fin_queued = True
        self._try_send()
        try:
            await asyncio.wait_for(asyncio.shield(self.closed), timeout)
        except asyncio.TimeoutError:
            self._abort(ConnectionTimeout("close timed out"))
        if self.error and not isinstance(self.error, ConnectionReset):
            raise self.error

    def abort(self) -> None:
        """Resets the connection right away (sends RST)."""
        if self.state != State.CLOSED:
            self._send_rst()
            self._abort(ConnectionReset("connection aborted locally"))

    def info(self) -> dict:
        return {
            "state": self.state.value, "cc": self.cc.name, "cwnd": int(self.cc.cwnd),
            "srtt": self.rtt.srtt, "rto": self.rtt.rto, "min_rtt": self.rtt.min_rtt,
            **self.stats,
        }
