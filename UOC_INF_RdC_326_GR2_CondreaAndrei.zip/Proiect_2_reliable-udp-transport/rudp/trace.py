"""Writes what the congestion controller is doing, as it happens.

One line per event (every ACK, loss, timeout and state change) with cwnd,
ssthresh, pipe, srtt, rto and the bytes acknowledged so far. JSON Lines or CSV,
picked from the file extension. Listeners can also subscribe in memory, which
is how the dashboard gets its live charts.
"""

from __future__ import annotations

import csv
import json
import time

FIELDS = ["t", "wall", "event", "conn", "state", "cwnd", "ssthresh", "pipe", "srtt", "rto", "rtt",
          "peer_wnd", "acked", "retx", "recovery"]


class Tracer:
    def __init__(self, path: str | None = None, min_interval: float = 0.0):
        self.min_interval = min_interval
        self._last = {}
        self.subscribers = []
        self.count = 0
        self._file = None
        self._csv = None
        if path:
            self._file = open(path, "w", newline="")
            if path.endswith(".csv"):
                self._csv = csv.DictWriter(self._file, fieldnames=FIELDS)
                self._csv.writeheader()

    def __call__(self, row: dict) -> None:
        # ACK samples can be thinned out; losses, timeouts and state changes never are
        if self.min_interval and row["event"] == "ack":
            now = time.monotonic()
            if now - self._last.get(row["conn"], 0) < self.min_interval:
                return
            self._last[row["conn"]] = now
        self.count += 1
        if self._csv:
            self._csv.writerow(row)
        elif self._file:
            self._file.write(json.dumps(row) + "\n")
        for fn in self.subscribers:
            fn(row)

    def close(self) -> None:
        if self._file:
            self._file.close()
            self._file = None
