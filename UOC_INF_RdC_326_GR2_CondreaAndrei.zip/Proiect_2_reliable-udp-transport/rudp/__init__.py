"""RUDP: a reliable, congestion-controlled byte stream over UDP.

    import asyncio, rudp

    async def main():
        listener = await rudp.listen("0.0.0.0", 9000)
        conn = await rudp.connect("127.0.0.1", 9000, options=rudp.Options(cc="cubic"))
        server_side = await listener.accept()
        await conn.send(b"hello")
        print(await server_side.recv())
        await conn.close()

The wire format and the algorithms are described in docs/SPEC.md.
"""

from .connection import (Connection, ConnectionError_ as RudpError, ConnectionReset,
                         ConnectionTimeout, Options, State)
from .endpoint import Listener, connect, listen

__version__ = "1.0.0"

__all__ = ["Connection", "Listener", "Options", "State", "RudpError", "ConnectionReset",
           "ConnectionTimeout", "connect", "listen", "__version__"]
