"""A set of half-open byte ranges [start, end), kept sorted and merged.

The receiver uses it to know which out-of-order bytes it holds, and to build
SACK blocks from them.
"""

from __future__ import annotations

import bisect


class RangeSet:
    def __init__(self):
        self._starts: list[int] = []
        self._ends: list[int] = []

    def __len__(self):
        return len(self._starts)

    def __iter__(self):
        return iter(zip(self._starts, self._ends))

    def __bool__(self):
        return bool(self._starts)

    def add(self, start: int, end: int) -> None:
        if end <= start:
            return
        i = bisect.bisect_left(self._ends, start)       # first range that may touch
        j = bisect.bisect_right(self._starts, end)      # first range strictly after
        if i < j:
            start = min(start, self._starts[i])
            end = max(end, self._ends[j - 1])
        self._starts[i:j] = [start]
        self._ends[i:j] = [end]

    def remove_below(self, point: int) -> None:
        """Forget everything before point (it has been delivered in order)."""
        while self._starts and self._ends[0] <= point:
            del self._starts[0]
            del self._ends[0]
        if self._starts and self._starts[0] < point:
            self._starts[0] = point

    def covering(self, point: int) -> tuple[int, int] | None:
        i = bisect.bisect_right(self._starts, point) - 1
        if i >= 0 and self._ends[i] > point:
            return self._starts[i], self._ends[i]
        return None

    def total(self) -> int:
        return sum(e - s for s, e in self)

    def blocks(self, recent: int | None = None, limit: int = 4) -> list[tuple[int, int]]:
        """SACK blocks: the one holding the most recent byte first (RFC 2018, 4),
        then the others from the highest down."""
        out = []
        first = self.covering(recent) if recent is not None else None
        if first:
            out.append(first)
        for r in reversed(list(self)):
            if len(out) >= limit:
                break
            if r != first:
                out.append(r)
        return out
