"""A UDP relay that damages traffic on purpose: delay, jitter, loss,
duplication, corruption and a rate-limited queue.

The real experiments use Linux netem inside Docker (see testbed/). This relay
exists so the integration tests and the local demo can run on any machine,
including macOS, where netem is not available.

    client -> relay (listen_port) -> server (target)
           <-                     <-
"""

from __future__ import annotations

import asyncio
import random
from dataclasses import dataclass


@dataclass
class Impairment:
    delay: float = 0.0          # one way, seconds
    jitter: float = 0.0         # uniform extra delay, seconds (reorders packets)
    loss: float = 0.0           # probability
    duplicate: float = 0.0
    corrupt: float = 0.0
    rate_bps: float = 0.0       # bottleneck rate, 0 = unlimited
    queue_packets: int = 100    # tail-drop queue behind the bottleneck
    seed: int | None = None


class _Direction:
    def __init__(self, relay, imp: Impairment, rng: random.Random):
        self.relay = relay
        self.imp = imp
        self.rng = rng
        self.busy_until = 0.0
        self.queued = 0
        self.counters = {"in": 0, "out": 0, "lost": 0, "queue_drop": 0, "dup": 0, "corrupt": 0}

    def push(self, data: bytes, send) -> None:
        loop = asyncio.get_running_loop()
        imp, rng, c = self.imp, self.rng, self.counters
        c["in"] += 1
        if rng.random() < imp.loss:
            c["lost"] += 1
            return
        copies = 2 if rng.random() < imp.duplicate else 1
        if copies == 2:
            c["dup"] += 1
        now = loop.time()
        for _ in range(copies):
            pkt = data
            if rng.random() < imp.corrupt:
                b = bytearray(pkt)
                b[rng.randrange(len(b))] ^= 1 << rng.randrange(8)
                pkt = bytes(b)
                c["corrupt"] += 1
            start = now
            if imp.rate_bps:
                if self.queued >= imp.queue_packets:
                    c["queue_drop"] += 1
                    continue
                self.busy_until = max(now, self.busy_until) + len(pkt) * 8 / imp.rate_bps
                start = self.busy_until
                self.queued += 1
            delay = start - now + imp.delay + (rng.random() * imp.jitter if imp.jitter else 0)
            loop.call_later(max(delay, 0), self._deliver, pkt, send, bool(imp.rate_bps))

    def _deliver(self, pkt, send, queued):
        if queued:
            self.queued -= 1
        self.counters["out"] += 1
        send(pkt)


class Relay:
    """Forwards between one client and a fixed server address."""

    def __init__(self, target: tuple[str, int], forward: Impairment, backward: Impairment | None = None):
        self.target = target
        rng = random.Random(forward.seed)
        self.fwd = _Direction(self, forward, rng)
        self.bwd = _Direction(self, backward or Impairment(delay=forward.delay, seed=forward.seed), rng)
        self.client = None
        self._front = None
        self._back = None

    async def start(self, host: str = "127.0.0.1", port: int = 0) -> tuple[str, int]:
        loop = asyncio.get_running_loop()
        relay = self

        class Front(asyncio.DatagramProtocol):
            def connection_made(self, t):
                relay._front = t

            def datagram_received(self, data, addr):
                relay.client = addr
                relay.fwd.push(data, lambda p: relay._back and relay._back.sendto(p, relay.target))

        class Back(asyncio.DatagramProtocol):
            def connection_made(self, t):
                relay._back = t

            def datagram_received(self, data, addr):
                if relay.client:
                    relay.bwd.push(data, lambda p: relay._front and relay._front.sendto(p, relay.client))

        await loop.create_datagram_endpoint(Front, local_addr=(host, port))
        await loop.create_datagram_endpoint(Back, local_addr=(host, 0))
        return self._front.get_extra_info("sockname")

    def close(self):
        for t in (self._front, self._back):
            if t:
                t.close()
