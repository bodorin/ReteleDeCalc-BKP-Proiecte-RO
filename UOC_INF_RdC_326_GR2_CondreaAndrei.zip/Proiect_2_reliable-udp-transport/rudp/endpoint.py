"""The UDP socket side: one Endpoint per local port, many connections on it.

Incoming datagrams are decoded and handed to the connection identified by
(peer address, connection ID). A listening endpoint creates connections for new
SYNs and hands them to accept() once their handshake completes.
"""

from __future__ import annotations

import asyncio
import random
import socket

from . import seqnum, wire
from .connection import Connection, Options, State


class Endpoint(asyncio.DatagramProtocol):
    def __init__(self, options: Options, tracer=None, impair=None):
        self.opts = options
        self.tracer = tracer
        self.impair = impair            # optional function(bytes) -> bool, for tests only
        self.transport: asyncio.DatagramTransport | None = None
        self.conns: dict[tuple, Connection] = {}
        self.listener: Listener | None = None
        self.dropped = {"malformed": 0, "unknown": 0}

    # asyncio.DatagramProtocol -------------------------------------------

    def connection_made(self, transport):
        self.transport = transport
        sock = transport.get_extra_info("socket")
        for opt in (socket.SO_RCVBUF, socket.SO_SNDBUF):
            try:
                # the default UDP buffers overflow long before a 4 MB window does
                sock.setsockopt(socket.SOL_SOCKET, opt, 4 * 1024 * 1024)
            except OSError:
                pass

    def datagram_received(self, data, addr):
        try:
            seg = wire.decode(data)
        except wire.DecodeError:
            self.dropped["malformed"] += 1
            return
        conn = self.conns.get((addr, seg.conn_id))
        if conn is not None:
            conn.on_segment(seg)
            return
        if seg.has(wire.SYN) and not seg.has(wire.ACK) and self.listener:
            self.listener.on_syn(seg, addr)
            return
        self.dropped["unknown"] += 1
        if not seg.has(wire.RST):
            # nothing here by that name: reset it (SPEC section 4)
            self.send_segment(wire.Segment(seg.conn_id, seg.ack, seqnum.add(seg.seq, seg.seg_len),
                                           wire.RST | wire.ACK), addr)

    def error_received(self, exc):
        pass  # ICMP port unreachable and friends; the timers deal with it

    # used by connections --------------------------------------------------

    def send_segment(self, seg: wire.Segment, addr) -> None:
        if self.transport is None or self.transport.is_closing():
            return
        data = wire.encode(seg)
        if self.impair and self.impair(data):
            return
        self.transport.sendto(data, addr)

    def add(self, conn: Connection) -> None:
        self.conns[(conn.peer, conn.conn_id)] = conn

    def forget(self, conn: Connection) -> None:
        self.conns.pop((conn.peer, conn.conn_id), None)
        if self.listener:
            self.listener.half_open.discard(conn)
        elif not self.conns:
            self.close()   # a client socket lives exactly as long as its connection

    def close(self) -> None:
        if self.transport:
            self.transport.close()

    @property
    def local_address(self):
        return self.transport.get_extra_info("sockname")


class Listener:
    def __init__(self, endpoint: Endpoint, backlog: int = 64):
        self.endpoint = endpoint
        self.backlog = backlog
        self.half_open: set[Connection] = set()
        self.queue: asyncio.Queue[Connection] = asyncio.Queue()
        self.syn_dropped = 0

    def on_syn(self, seg: wire.Segment, addr) -> None:
        if len(self.half_open) >= self.backlog:
            self.syn_dropped += 1      # bounded state under a SYN flood
            return
        conn = Connection(self.endpoint, addr, seg.conn_id, self.endpoint.opts,
                          tracer=self.endpoint.tracer)
        self.endpoint.add(conn)
        self.half_open.add(conn)
        conn.start_passive_open(seg)
        conn.established.add_done_callback(lambda f, c=conn: self._on_established(c, f))

    def _on_established(self, conn: Connection, fut) -> None:
        self.half_open.discard(conn)
        if not fut.cancelled() and fut.exception() is None:
            self.queue.put_nowait(conn)

    async def accept(self) -> Connection:
        while True:
            conn = await self.queue.get()
            if conn.state != State.CLOSED:
                return conn

    @property
    def address(self):
        return self.endpoint.local_address

    def close(self) -> None:
        self.endpoint.close()


async def open_endpoint(host: str, port: int, options: Options, tracer=None, impair=None) -> Endpoint:
    loop = asyncio.get_running_loop()
    _, proto = await loop.create_datagram_endpoint(
        lambda: Endpoint(options, tracer, impair), local_addr=(host, port))
    return proto


async def connect(host: str, port: int, *, options: Options | None = None, tracer=None,
                  impair=None, local_host: str = "0.0.0.0", timeout: float = 30.0) -> Connection:
    """Opens a connection to a listening RUDP endpoint."""
    opts = options or Options()
    loop = asyncio.get_running_loop()
    infos = await loop.getaddrinfo(host, port, family=0, type=2)  # SOCK_DGRAM
    addr = infos[0][4][:2]
    ep = await open_endpoint(local_host, 0, opts, tracer, impair)
    conn = Connection(ep, addr, random.getrandbits(32), opts, tracer=tracer)
    ep.add(conn)
    conn.start_active_open()
    try:
        await asyncio.wait_for(asyncio.shield(conn.established), timeout)
    except BaseException:
        conn.abort()
        ep.close()
        raise
    return conn


async def listen(host: str, port: int, *, options: Options | None = None, tracer=None,
                 impair=None, backlog: int = 64) -> Listener:
    """Starts accepting RUDP connections on host:port."""
    ep = await open_endpoint(host, port, options or Options(), tracer, impair)
    ep.listener = Listener(ep, backlog)
    return ep.listener
