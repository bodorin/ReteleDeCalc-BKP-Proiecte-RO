"""The full experiment set, run against the Docker testbed.

    python testbed/experiments.py matrix      # rudp vs Linux TCP over a grid of paths
    python testbed/experiments.py fairness    # two flows sharing one bottleneck
    python testbed/experiments.py traces      # cwnd traces for the charts
    python testbed/experiments.py captures    # pcaps of rudp and TCP, decoded with tshark
    python testbed/experiments.py all

Every result lands in results/. Each matrix cell is repeated (--reps) and the
summary keeps the mean, the standard deviation and a 95% confidence interval.
"""

from __future__ import annotations

import argparse
import csv
import json
import statistics
import subprocess
import time
from pathlib import Path

import lab
from lab import Path_

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"

FLOWS = [("rudp", "reno"), ("rudp", "cubic"), ("rudp", "fixed"), ("tcp", "reno"), ("tcp", "cubic")]


def one_run(impl: str, cc: str, size: int) -> dict:
    lab.kill_servers()
    if impl == "rudp":
        return lab.run_rudp(cc, size)
    return lab.run_tcp(cc, size)


def matrix(reps: int, size: int) -> None:
    paths = [Path_(10, rtt, loss, 50) for rtt in (20, 80) for loss in (0.0, 0.005, 0.02)]
    raw_path = RESULTS / "matrix_runs.csv"
    rows = []
    total = len(paths) * len(FLOWS) * reps
    n = 0
    for p in paths:
        lab.shape(p)
        for rep in range(reps):
            for impl, cc in FLOWS:          # interleaved, so slow drifts hit everyone alike
                n += 1
                try:
                    r = one_run(impl, cc, size)
                except Exception as e:      # a failed run is recorded, not hidden
                    r = {"impl": impl, "cc": cc, "error": str(e)[:200]}
                r.update({"rate_mbit": p.rate_mbit, "rtt_ms": p.rtt_ms, "loss": p.loss,
                          "queue": p.queue, "rep": rep})
                rows.append(r)
                print(f"[{n}/{total}] {p.label():22} {impl}-{cc:5} "
                      f"{r.get('goodput_mbps', 'ERR')} Mbit/s retx={r.get('retransmissions')}", flush=True)
    lab.unshape()
    keys = ["impl", "cc", "rate_mbit", "rtt_ms", "loss", "queue", "rep", "bytes", "seconds",
            "goodput_mbps", "retransmissions", "timeouts", "fast_recoveries", "srtt_ms", "min_rtt_ms",
            "verified", "error"]
    write_csv(raw_path, rows, keys)
    summarize(rows)


def summarize(rows: list[dict]) -> None:
    groups: dict[tuple, list[dict]] = {}
    for r in rows:
        if "error" in r:
            continue
        groups.setdefault((r["impl"], r["cc"], r["rtt_ms"], r["loss"]), []).append(r)
    out = []
    for (impl, cc, rtt, loss), rs in sorted(groups.items()):
        g = [r["goodput_mbps"] for r in rs]
        mean = statistics.mean(g)
        sd = statistics.stdev(g) if len(g) > 1 else 0.0
        out.append({
            "impl": impl, "cc": cc, "rtt_ms": rtt, "loss": loss, "runs": len(g),
            "goodput_mean": round(mean, 3), "goodput_sd": round(sd, 3),
            "ci95": round(1.96 * sd / len(g) ** 0.5, 3) if len(g) > 1 else 0.0,
            "retx_mean": round(statistics.mean(float(r["retransmissions"] or 0) for r in rs), 1),
            "srtt_mean": round(statistics.mean(float(r["srtt_ms"] or 0) for r in rs), 1),
        })
    write_csv(RESULTS / "matrix_summary.csv", out, list(out[0]))


def write_csv(path: Path, rows: list[dict], keys: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    print("wrote", path.relative_to(ROOT))


# ------------------------------------------------------------------ fairness

def _bench_cmd(port: int, size: int, cc: str, trace: str) -> list[str]:
    return lab.COMPOSE + ["exec", "-T", "sender", "python", "-m", "rudp", "bench",
                          f"{lab.RECEIVER_IP}:{port}", "--size", str(size), "--cc", cc, "--json",
                          "--trace", trace, "--trace-interval", "0.05"]


def fairness(p: Path_, second_delay: float = 8.0) -> None:
    """rudp vs rudp, and rudp vs Linux TCP, on one bottleneck."""
    lab.shape(p)
    out = {}

    # 1. two rudp Reno flows, the second joins later
    lab.kill_servers()
    for port in (9000, 9001):
        lab.sh("receiver", "python", "-m", "rudp", "recv", "--listen", f"0.0.0.0:{port}",
               "--discard", "--once", detach=True)
    time.sleep(0.8)
    a = subprocess.Popen(_bench_cmd(9000, 40 << 20, "reno", "/tmp/flow_a.csv"), stdout=subprocess.PIPE, text=True)
    time.sleep(second_delay)
    b = subprocess.Popen(_bench_cmd(9001, 20 << 20, "reno", "/tmp/flow_b.csv"), stdout=subprocess.PIPE, text=True)
    a.wait(), b.wait()
    for name in ("flow_a", "flow_b"):
        lab.copy_out("sender", f"/tmp/{name}.csv", RESULTS / "traces" / f"fair_rudp_{name}.csv")
    out["rudp_vs_rudp"] = {"a": a.stdout.read(), "b": b.stdout.read()}

    # 2. rudp CUBIC against Linux TCP CUBIC, started together
    lab.kill_servers()
    lab.sh("receiver", "python", "-m", "rudp", "recv", "--listen", "0.0.0.0:9000",
           "--discard", "--once", detach=True)
    lab.sh("receiver", "iperf3", "-s", "-1", "-p", "5201", detach=True)
    time.sleep(0.8)
    tcp = subprocess.Popen(lab.COMPOSE + ["exec", "-T", "sender", "iperf3", "-c", lab.RECEIVER_IP,
                                          "-p", "5201", "-t", "40", "-C", "cubic", "-i", "0.5", "-J"],
                           stdout=subprocess.PIPE, text=True)
    t_start = time.time()
    ru = subprocess.Popen(_bench_cmd(9000, 25 << 20, "cubic", "/tmp/flow_c.csv"), stdout=subprocess.PIPE, text=True)
    ru.wait()
    tcp_out = tcp.communicate()[0]
    lab.copy_out("sender", "/tmp/flow_c.csv", RESULTS / "traces" / "fair_vs_tcp_rudp.csv")
    d = json.loads(tcp_out)
    out["rudp_vs_tcp"] = {
        "rudp": ru.stdout.read(),
        "tcp_start_wall": d["start"]["timestamp"]["timesecs"],
        "host_start_wall": t_start,
        "tcp_intervals": [(iv["sum"]["start"], iv["sum"]["end"], iv["sum"]["bits_per_second"])
                          for iv in d["intervals"]],
    }
    lab.unshape()
    path = RESULTS / "fairness.json"
    path.write_text(json.dumps({"path": p.label(), **out}, indent=1))
    print("wrote", path.relative_to(ROOT))


# ------------------------------------------------------------------ captures

def captures(p: Path_) -> None:
    """Packet captures on the receiver, rudp and Linux TCP over the same lossy path,
    plus a decoded text version of each made with tshark and the rudp dissector."""
    lab.shape(p)
    out = RESULTS / "captures"
    for name, port, filt in (("rudp_reno_2pct", 9000, "udp port 9000"), ("tcp_reno_2pct", 5201, "tcp port 5201")):
        lab.kill_servers()
        lab.sh("receiver", "pkill", "tcpdump", check=False)
        lab.sh("receiver", "tcpdump", "-i", "eth0", "-s", "128", "-w", f"/tmp/{name}.pcap", filt, detach=True)
        time.sleep(1.0)
        if port == 9000:
            lab.run_rudp("reno", 400_000)
        else:
            lab.run_tcp("reno", 400_000)
        time.sleep(1.0)
        lab.sh("receiver", "pkill", "-INT", "tcpdump", check=False)
        time.sleep(1.0)
        # tshark refuses personal Lua plugins as root, so decode as an unprivileged user
        lab.sh("receiver", "sh", "-c", f"cp /root/.local/lib/wireshark/plugins/rudp.lua /tmp/ && chmod 644 /tmp/rudp.lua /tmp/{name}.pcap")
        text = lab.sh("receiver", "su", "nobody", "-s", "/bin/sh", "-c",
                      f"HOME=/tmp tshark -X lua_script:/tmp/rudp.lua -r /tmp/{name}.pcap")
        out.mkdir(parents=True, exist_ok=True)
        (out / f"{name}.txt").write_text(text)
        lab.copy_out("receiver", f"/tmp/{name}.pcap", out / f"{name}.pcap")
        print("captured", name, len(text.splitlines()), "packets")
    lab.unshape()


# -------------------------------------------------------------------- traces

def traces(p: Path_) -> None:
    lab.shape(p)
    for cc in ("reno", "cubic"):
        lab.kill_servers()
        r = lab.run_rudp(cc, 30 << 20, trace=f"/tmp/trace_{cc}.csv", trace_interval=0.02)
        lab.copy_out("sender", f"/tmp/trace_{cc}.csv", RESULTS / "traces" / f"single_{cc}.csv")
        print(cc, r["goodput_mbps"], "Mbit/s")
    lab.unshape()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("what", choices=["matrix", "fairness", "traces", "captures", "all"])
    ap.add_argument("--reps", type=int, default=5)
    ap.add_argument("--size", type=int, default=4 << 20)
    o = ap.parse_args()
    bottleneck = Path_(rate_mbit=10, rtt_ms=40, loss=0.0, queue=50)
    if o.what in ("traces", "all"):
        traces(bottleneck)
    if o.what in ("captures", "all"):
        captures(Path_(rate_mbit=10, rtt_ms=40, loss=0.02, queue=50))
    if o.what in ("fairness", "all"):
        fairness(bottleneck)
    if o.what in ("matrix", "all"):
        matrix(o.reps, o.size)
