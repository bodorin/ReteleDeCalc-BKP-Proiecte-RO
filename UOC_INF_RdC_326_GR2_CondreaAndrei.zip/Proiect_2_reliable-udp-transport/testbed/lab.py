"""Drives the two-container testbed from the host.

Everything goes through `docker compose exec`, so the same script works on
Linux, macOS and Windows as long as Docker is running:

    docker compose -f testbed/docker-compose.yml up -d --build
    python testbed/lab.py check
"""

from __future__ import annotations

import json
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path

HERE = Path(__file__).resolve().parent
COMPOSE = ["docker", "compose", "-f", str(HERE / "docker-compose.yml")]
RECEIVER_IP = "10.77.0.20"


def sh(service: str, *cmd: str, detach: bool = False, check: bool = True, timeout: float = 600) -> str:
    args = COMPOSE + ["exec", "-T"] + (["-d"] if detach else []) + [service, *cmd]
    out = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    if check and out.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd)} failed on {service}: {out.stderr.strip()}")
    return out.stdout


@dataclass
class Path_:
    """One network condition. Delay is split evenly over both directions."""
    rate_mbit: float = 10
    rtt_ms: float = 40
    loss: float = 0.0              # on the data direction (sender -> receiver)
    queue: int = 50                # packets in the bottleneck queue

    def label(self) -> str:
        return f"{self.rate_mbit:g}Mbit {self.rtt_ms:g}ms {self.loss * 100:g}% q{self.queue}"


def no_offloads() -> None:
    # Linux TCP would hand netem 64 KB super-packets (TSO/GSO) and slip past the
    # rate limit; with offloads off both protocols go through it packet by packet
    for s in ("sender", "receiver"):
        sh(s, "ethtool", "-K", "eth0", "tso", "off", "gso", "off", "gro", "off", check=False)


def shape(p: Path_) -> None:
    no_offloads()
    half = f"{p.rtt_ms / 2:g}ms"
    sh("sender", "tc", "qdisc", "replace", "dev", "eth0", "root", "netem", "delay", half,
       "loss", f"{p.loss * 100:g}%", "rate", f"{p.rate_mbit:g}mbit", "limit", str(p.queue))
    sh("receiver", "tc", "qdisc", "replace", "dev", "eth0", "root", "netem", "delay", half)


def unshape() -> None:
    for s in ("sender", "receiver"):
        sh(s, "tc", "qdisc", "del", "dev", "eth0", "root", check=False)


def kill_servers() -> None:
    for s in ("receiver", "sender"):
        sh(s, "pkill", "-f", "rudp recv|iperf3", check=False)


def run_rudp(cc: str, size: int, port: int = 9000, trace: str | None = None,
             trace_interval: float = 0.0, window: int = 32) -> dict:
    sh("receiver", "python", "-m", "rudp", "recv", "--listen", f"0.0.0.0:{port}",
       "--discard", "--once", detach=True)
    time.sleep(0.6)
    cmd = ["python", "-m", "rudp", "bench", f"{RECEIVER_IP}:{port}", "--size", str(size),
           "--cc", cc, "--window", str(window), "--json"]
    if trace:
        cmd += ["--trace", trace, "--trace-interval", str(trace_interval)]
    r = json.loads(sh("sender", *cmd).strip().splitlines()[-1])
    r["impl"] = "rudp"
    return r


def run_tcp(cc: str, size: int, port: int = 5201, interval: float | None = None) -> dict:
    sh("receiver", "iperf3", "-s", "-1", "-p", str(port), detach=True)
    time.sleep(0.6)
    cmd = ["iperf3", "-c", RECEIVER_IP, "-p", str(port), "-n", str(size), "-C", cc, "-J"]
    if interval:
        cmd += ["-i", str(interval)]
    d = json.loads(sh("sender", *cmd))
    end = d["end"]
    secs = end["sum_received"]["seconds"]
    out = {
        "impl": "tcp", "cc": cc, "bytes": size, "seconds": round(secs, 4),
        "goodput_mbps": round(size * 8 / secs / 1e6, 3),
        "retransmissions": end["sum_sent"].get("retransmits", 0),
        "srtt_ms": round(end["streams"][0]["sender"].get("mean_rtt", 0) / 1000, 2),
        "min_rtt_ms": round(end["streams"][0]["sender"].get("min_rtt", 0) / 1000, 2),
    }
    if interval:
        out["intervals"] = [(iv["sum"]["start"], iv["sum"]["end"], iv["sum"]["bits_per_second"])
                            for iv in d["intervals"]]
    return out


def copy_out(service: str, path: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    container = subprocess.run(COMPOSE + ["ps", "-q", service], capture_output=True, text=True).stdout.strip()
    subprocess.run(["docker", "cp", f"{container}:{path}", str(dest)], check=True, capture_output=True)


if __name__ == "__main__" and sys.argv[1:] == ["check"]:
    kill_servers()
    shape(Path_(rate_mbit=10, rtt_ms=40))
    print("rudp reno:", run_rudp("reno", 5 << 20))
    print("tcp  reno:", run_tcp("reno", 5 << 20))
    unshape()
