"""The dashboard: a small asyncio HTTP server, no framework.

    python -m dashboard            # then open http://localhost:8080

/api/live runs a real rudp transfer on this machine, through the impairing
relay, and streams what happens as Server-Sent Events. /api/results serves the
numbers the Docker testbed wrote to results/.
"""

from __future__ import annotations

import asyncio
import json
import mimetypes
import os
import time
import urllib.parse
from pathlib import Path

import rudp
from rudp.impair import Impairment, Relay
from rudp.trace import Tracer
from rudp.transfer import receive_file, send_random

from .data import load_results

STATIC = Path(__file__).resolve().parent / "static"
LIMITS = {"size": (1, 64), "rate": (1, 50), "rtt": (2, 400), "loss": (0, 20), "queue": (5, 500)}


def _num(q: dict, key: str, default: float) -> float:
    try:
        v = float(q.get(key, [default])[0])
    except ValueError:
        v = default
    lo, hi = LIMITS.get(key, (v, v))
    return min(max(v, lo), hi)


class Client:
    def __init__(self, writer):
        self.writer = writer
        self.open = True

    async def event(self, kind: str, data) -> None:
        if not self.open:
            return
        try:
            self.writer.write(f"event: {kind}\ndata: {json.dumps(data)}\n\n".encode())
            await self.writer.drain()
        except (ConnectionError, RuntimeError):
            self.open = False


async def live_run(client: Client, q: dict) -> None:
    cc = q.get("cc", ["reno"])[0]
    if cc not in ("reno", "cubic", "fixed"):
        cc = "reno"
    size = int(_num(q, "size", 8) * (1 << 20))
    link = Impairment(delay=_num(q, "rtt", 40) / 2000, loss=_num(q, "loss", 0) / 100,
                      rate_bps=_num(q, "rate", 10) * 1e6, queue_packets=int(_num(q, "queue", 50)))
    back = Impairment(delay=link.delay)

    pending = []
    tracer = Tracer(min_interval=0.025)
    tracer.subscribers.append(lambda row: row["conn"] == own.get("id") and pending.append(row))
    own = {}

    listener = await rudp.listen("127.0.0.1", 0, options=rudp.Options(msl=0.2))
    relay = Relay(listener.address, link, back)
    front = await relay.start()
    started = time.perf_counter()
    try:
        conn = await rudp.connect(*front, options=rudp.Options(cc=cc, msl=0.2), tracer=tracer)
        own["id"] = f"{conn.conn_id:08x}"
        server = await listener.accept()
        await client.event("start", {"cc": cc, "size": size, "rtt": link.delay * 2000,
                                     "rate": link.rate_bps / 1e6, "loss": link.loss * 100})
        recv_task = asyncio.create_task(receive_file(server, None))
        send_task = asyncio.create_task(send_random(conn, size))

        last = dict(relay.fwd.counters)
        while not send_task.done() and client.open:
            await asyncio.sleep(0.1)
            now = dict(relay.fwd.counters)
            wire = {k: now[k] - last.get(k, 0) for k in now}
            wire["acks"] = relay.bwd.counters["out"]
            wire["queued"] = relay.fwd.queued
            last = now
            batch, pending[:] = pending[:], []
            await client.event("tick", {"t": time.perf_counter() - started, "trace": batch,
                                        "wire": wire, "stats": conn.info()})
        if not client.open:
            conn.abort()
            return
        result = await send_task
        await recv_task
        await client.event("done", result)
    except Exception as e:
        await client.event("error", {"message": str(e)})
    finally:
        relay.close()
        listener.close()


async def handle(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        request = await reader.readline()
        while (await reader.readline()) not in (b"\r\n", b"\n", b""):
            pass
        method, target, _ = request.decode().split(" ", 2)
    except (ValueError, ConnectionError):
        writer.close()
        return
    url = urllib.parse.urlparse(target)
    q = urllib.parse.parse_qs(url.query)

    if url.path == "/api/live":
        writer.write(b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\n"
                     b"Cache-Control: no-cache\r\nConnection: close\r\n\r\n")
        await live_run(Client(writer), q)
    elif url.path == "/api/results":
        body = json.dumps(load_results()).encode()
        writer.write(b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n"
                     + f"Content-Length: {len(body)}\r\n\r\n".encode() + body)
    else:
        rel = "index.html" if url.path in ("/", "") else url.path.lstrip("/")
        path = (STATIC / rel).resolve()
        if STATIC not in path.parents or not path.is_file():
            writer.write(b"HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n")
        else:
            body = path.read_bytes()
            ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
            writer.write(f"HTTP/1.1 200 OK\r\nContent-Type: {ctype}\r\n"
                         f"Content-Length: {len(body)}\r\n\r\n".encode() + body)
    try:
        await writer.drain()
        writer.close()
    except ConnectionError:
        pass


async def serve(port: int) -> None:
    server = await asyncio.start_server(handle, "127.0.0.1", port)
    print(f"dashboard on http://localhost:{port}  (Ctrl+C to stop)")
    async with server:
        await server.serve_forever()


def main() -> None:
    port = int(os.environ.get("PORT", "8080"))
    try:
        asyncio.run(serve(port))
    except KeyboardInterrupt:
        pass
