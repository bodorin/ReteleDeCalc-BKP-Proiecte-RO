"""Reads what the testbed wrote to results/ and shapes it for the charts."""

from __future__ import annotations

import bisect
import csv
import json
from pathlib import Path

RESULTS = Path(__file__).resolve().parent.parent / "results"


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with open(path) as f:
        return list(csv.DictReader(f))


def trace(path: Path, max_points: int = 1500) -> list[list[float]]:
    """[t, cwnd_segments, ssthresh_segments, srtt_ms] rows, thinned for the browser."""
    rows = [r for r in _read_csv(path) if r.get("cwnd")]
    step = max(1, len(rows) // max_points)
    out = []
    for i, r in enumerate(rows):
        if i % step and r["event"] == "ack":
            continue
        out.append([float(r["t"]), int(r["cwnd"]) / 1200,
                    int(r["ssthresh"]) / 1200 if r["ssthresh"] else None,
                    float(r["srtt"]) * 1000 if r["srtt"] else None])
    return out


def acked_series(path: Path) -> list[tuple[float, int]]:
    return [(float(r["wall"]), int(r["acked"])) for r in _read_csv(path) if r.get("acked")]


def rate_between(pts, a: float, b: float) -> float:
    """Mbit/s acknowledged between wall times a and b."""
    ts = [p[0] for p in pts]
    i, j = bisect.bisect_left(ts, a), bisect.bisect_right(ts, b) - 1
    if j <= i:
        return 0.0
    return (pts[j][1] - pts[i][1]) * 8 / (pts[j][0] - pts[i][0]) / 1e6


def jain(xs: list[float]) -> float:
    return sum(xs) ** 2 / (len(xs) * sum(x * x for x in xs)) if any(xs) else 0.0


def fairness(step: float = 1.0) -> dict:
    meta_path = RESULTS / "fairness.json"
    if not meta_path.exists():
        return {}
    meta = json.loads(meta_path.read_text())
    out = {"path": meta.get("path")}

    a = acked_series(RESULTS / "traces" / "fair_rudp_flow_a.csv")
    b = acked_series(RESULTS / "traces" / "fair_rudp_flow_b.csv")
    if a and b:
        t0, t1 = a[0][0], max(a[-1][0], b[-1][0])
        times = [t0 + i * step for i in range(int((t1 - t0) / step) + 1)]
        out["rudp_vs_rudp"] = {
            "t": [round(t - t0, 2) for t in times],
            "a": [round(rate_between(a, t, t + step), 3) for t in times],
            "b": [round(rate_between(b, t, t + step), 3) for t in times],
        }
        s, e = max(a[0][0], b[0][0]) + 2, min(a[-1][0], b[-1][0])
        x = [rate_between(a, s, e), rate_between(b, s, e)]
        out["rudp_vs_rudp"].update({"share": [round(v, 3) for v in x], "jain": round(jain(x), 4)})

    c = acked_series(RESULTS / "traces" / "fair_vs_tcp_rudp.csv")
    vt = meta.get("rudp_vs_tcp", {})
    if c and vt.get("tcp_intervals"):
        t0 = vt["tcp_start_wall"]
        iv = vt["tcp_intervals"]
        start = min(c[0][0], t0)
        times = [start + i * step for i in range(int((max(c[-1][0], t0 + iv[-1][1]) - start) / step) + 1)]

        def tcp_rate(t):
            vals = [bps for (s0, s1, bps) in iv if t <= t0 + s0 < t + step]
            return sum(vals) / len(vals) / 1e6 if vals else 0.0

        out["rudp_vs_tcp"] = {
            "t": [round(t - start, 2) for t in times],
            "rudp": [round(rate_between(c, t, t + step), 3) for t in times],
            "tcp": [round(tcp_rate(t), 3) for t in times],
        }
        s, e = max(c[0][0], t0) + 2, min(c[-1][0], t0 + iv[-1][1])
        tcp_vals = [bps for (s0, s1, bps) in iv if t0 + s0 >= s and t0 + s1 <= e]
        x = [rate_between(c, s, e), sum(tcp_vals) / max(len(tcp_vals), 1) / 1e6]
        out["rudp_vs_tcp"].update({"share": [round(v, 3) for v in x], "jain": round(jain(x), 4)})
    return out


def load_results() -> dict:
    return {
        "matrix": _read_csv(RESULTS / "matrix_summary.csv"),
        "fairness": fairness(),
        "traces": {cc: trace(RESULTS / "traces" / f"single_{cc}.csv") for cc in ("reno", "cubic")},
    }
