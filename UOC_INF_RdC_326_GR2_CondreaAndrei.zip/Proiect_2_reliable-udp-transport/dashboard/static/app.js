const $ = s => document.querySelector(s);
const MSS = 1200;

// ------------------------------------------------------------------ pages
function show(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.toggle("active", p.id === "page-" + page));
  document.querySelectorAll("[data-page]").forEach(b => b.setAttribute("aria-selected", b.dataset.page === page));
  if (page === "results") loadResults();
  if (page === "live") requestAnimationFrame(() => { cwndChart.draw(); rttChart.draw(); });
}
document.querySelectorAll("[data-page]").forEach(b => b.addEventListener("click", () => { location.hash = b.dataset.page; }));
window.addEventListener("hashchange", () => show(location.hash.slice(1).replace("run", "live") || "live"));

// ------------------------------------------------------------------ controls
let cc = "reno";
document.querySelectorAll("[data-cc]").forEach(b => b.addEventListener("click", () => {
  cc = b.dataset.cc;
  document.querySelectorAll("[data-cc]").forEach(x => x.classList.toggle("on", x === b));
}));
const units = { rate: " Mbit/s", rtt: " ms", loss: " %", queue: " packets", size: " MB" };
for (const id in units) {
  const el = $("#" + id), out = $("#o-" + id);
  const sync = () => { out.textContent = el.value + units[id]; };
  el.addEventListener("input", sync); sync();
}

// ------------------------------------------------------------------ charts
const cwndChart = new LineChart($("#c-cwnd"), { minY: 20, series: [
  { color: "--data", label: "cwnd", fill: true, glow: true, head: true, step: true, width: 2 },
  { color: "--thresh", label: "ssthresh", dash: [6, 5], step: true },
] });
const rttChart = new LineChart($("#c-rtt"), { minY: 50, series: [
  { color: "--ack", label: "smoothed RTT", fill: true, head: true, width: 2 },
  { color: "--violet", label: "last sample", width: 1 },
] });

// ------------------------------------------------------------------ state machine
const FSM = {
  SYN_SENT: [20, 20], ESTABLISHED: [235, 20], FIN_WAIT_1: [450, 20],
  CLOSE_WAIT: [20, 95], FIN_WAIT_2: [450, 95], CLOSING: [235, 95],
  LAST_ACK: [20, 170], CLOSED: [235, 170], TIME_WAIT: [450, 170],
};
const EDGES = [["SYN_SENT", "ESTABLISHED"], ["ESTABLISHED", "FIN_WAIT_1"], ["FIN_WAIT_1", "FIN_WAIT_2"],
  ["FIN_WAIT_2", "TIME_WAIT"], ["TIME_WAIT", "CLOSED"], ["ESTABLISHED", "CLOSE_WAIT"],
  ["CLOSE_WAIT", "LAST_ACK"], ["LAST_ACK", "CLOSED"], ["FIN_WAIT_1", "CLOSING"], ["CLOSING", "TIME_WAIT"]];
(function drawFsm() {
  const W = 170, H = 40, c = n => [FSM[n][0] + W / 2, FSM[n][1] + H / 2];
  let svg = "";
  for (const [a, b] of EDGES) {
    const [x1, y1] = c(a), [x2, y2] = c(b);
    svg += `<path d="M${x1},${y1} L${x2},${y2}"/>`;
  }
  for (const n in FSM) {
    const [x, y] = FSM[n];
    svg += `<g class="node" data-s="${n}"><rect x="${x}" y="${y}" width="${W}" height="${H}" rx="10"/>` +
      `<text x="${x + W / 2}" y="${y + 25}" text-anchor="middle">${n}</text></g>`;
  }
  $("#fsm").innerHTML = svg;
})();
const visited = new Set();
function setState(s) {
  const pill = $("#conn-state");
  pill.textContent = s; pill.dataset.state = s;
  if (s) visited.add(s);
  document.querySelectorAll("#fsm .node").forEach(n => {
    n.classList.toggle("on", n.dataset.s === s);
    n.classList.toggle("past", visited.has(n.dataset.s) && n.dataset.s !== s);
  });
}

// ------------------------------------------------------------------ event log
function log(kind, t, text) {
  const ol = $("#log");
  if (ol.firstElementChild && ol.firstElementChild.classList.contains("muted")) ol.innerHTML = "";
  const li = document.createElement("li");
  li.className = kind;
  li.innerHTML = `<time>${t.toFixed(2)}s</time><span>${text}</span>`;
  ol.prepend(li);
  while (ol.children.length > 60) ol.lastChild.remove();
}

// ------------------------------------------------------------------ the wire
const wire = { particles: [], bursts: [], queue: 0, queueCap: 50, running: false };
function spawn(kind, n) {
  for (let i = 0; i < n; i++) {
    wire.particles.push({ kind, p: -Math.random() * 0.35, speed: 0.55 + Math.random() * 0.25, lane: Math.random() });
  }
}
function drawWire(ts) {
  const c = $("#wire"), dpr = window.devicePixelRatio || 1, w = c.clientWidth, h = 190;
  if (c.width !== w * dpr) { c.width = w * dpr; c.height = h * dpr; c.style.height = h + "px"; }
  const g = c.getContext("2d");
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, w, h);
  const dt = Math.min(0.05, (ts - (wire.last || ts)) / 1000); wire.last = ts;
  const L = 90, R = w - 90, mid = w / 2, yD = 70, yA = 128;

  // pipes
  g.strokeStyle = "#1c2736"; g.lineWidth = 16; g.lineCap = "round";
  g.beginPath(); g.moveTo(L, yD); g.lineTo(R, yD); g.moveTo(L, yA); g.lineTo(R, yA); g.stroke();
  // router + queue
  g.fillStyle = "#121a25"; g.strokeStyle = "#2a3646"; g.lineWidth = 1.2;
  g.beginPath(); g.roundRect(mid - 46, yD - 22, 92, 50, 10); g.fill(); g.stroke();
  const qf = Math.min(1, wire.queue / wire.queueCap);
  g.fillStyle = "#1c2736"; g.fillRect(mid - 34, yD + 12, 68, 8);
  const qg = g.createLinearGradient(mid - 34, 0, mid + 34, 0);
  qg.addColorStop(0, css("--thresh")); qg.addColorStop(1, qf > 0.85 ? css("--loss") : css("--thresh"));
  g.fillStyle = qg; g.fillRect(mid - 34, yD + 12, 68 * qf, 8);
  g.fillStyle = css("--muted"); g.font = "11px 'JetBrains Mono', monospace"; g.textAlign = "center";
  g.fillText("bottleneck", mid, yD - 30);
  g.fillText(`queue ${Math.round(wire.queue)}/${wire.queueCap}`, mid, yD + 40);

  // hosts
  for (const [x, label] of [[L - 50, "sender"], [R + 50, "receiver"]]) {
    g.fillStyle = "#121a25"; g.strokeStyle = wire.running ? css("--data") : "#2a3646";
    g.shadowColor = css("--data"); g.shadowBlur = wire.running ? 14 : 0;
    g.beginPath(); g.roundRect(x - 40, yD - 22, 80, yA - yD + 44, 12); g.fill(); g.stroke();
    g.shadowBlur = 0; g.fillStyle = css("--text"); g.font = "600 12px 'Space Grotesk', sans-serif";
    g.fillText(label, x, (yD + yA) / 2 + 4);
  }

  // particles
  wire.particles = wire.particles.filter(pt => {
    pt.p += pt.speed * dt;
    if (pt.p < 0) return true;
    if (pt.kind === "lost" && pt.p >= 0.5) {
      wire.bursts.push({ x: mid - 30, y: yD + (pt.lane - 0.5) * 10, r: 2, a: 1 });
      return false;
    }
    if (pt.p > 1) return false;
    const ack = pt.kind === "ack";
    const x = ack ? R - (R - L) * pt.p : L + (R - L) * pt.p;
    const y = (ack ? yA : yD) + (pt.lane - 0.5) * 9;
    const color = ack ? css("--ack") : pt.kind === "lost" ? css("--loss") : css("--data");
    g.fillStyle = color; g.shadowColor = color; g.shadowBlur = 8;
    g.beginPath(); g.arc(x, y, ack ? 2.2 : 3, 0, 7); g.fill();
    g.shadowBlur = 0;
    return true;
  });
  wire.bursts = wire.bursts.filter(b => {
    b.r += 60 * dt; b.a -= 1.8 * dt;
    if (b.a <= 0) return false;
    g.strokeStyle = `rgba(255,107,107,${b.a})`; g.lineWidth = 2;
    g.beginPath(); g.arc(b.x, b.y, b.r, 0, 7); g.stroke();
    return true;
  });
  requestAnimationFrame(drawWire);
}
requestAnimationFrame(drawWire);

// ------------------------------------------------------------------ live run
let source = null;
function animateNumber(el, value, digits = 0) {
  el.textContent = (+value).toFixed(digits);
}
function flash(el) { el.classList.add("flash"); setTimeout(() => el.classList.remove("flash"), 500); }

$("#go").addEventListener("click", () => {
  if (source) source.close();
  const q = new URLSearchParams({ cc, rate: $("#rate").value, rtt: $("#rtt").value,
    loss: $("#loss").value, queue: $("#queue").value, size: $("#size").value });
  cwndChart.reset(); rttChart.reset(); visited.clear();
  $("#log").innerHTML = "";
  wire.queueCap = +$("#queue").value; wire.particles = []; wire.queue = 0;
  const btn = $("#go");
  btn.disabled = true; btn.classList.add("running"); btn.firstElementChild.textContent = "Transferring…";
  let size = 1, lastAcked = 0, lastT = 0, goodput = 0, lastRetx = 0;

  source = new EventSource("/api/live?" + q);
  source.addEventListener("start", e => {
    const d = JSON.parse(e.data);
    size = d.size; wire.running = true;
    log("state", 0, `${d.cc} over ${d.rate} Mbit/s, ${d.rtt} ms RTT, ${d.loss}% loss`);
  });
  source.addEventListener("tick", e => {
    const d = JSON.parse(e.data);
    for (const r of d.trace) {
      if (r.event === "state") { setState(r.state); log("state", r.t, `→ ${r.state}`); }
      if (r.event === "loss") log("loss", r.t, `loss detected, fast recovery: cwnd ${Math.round(r.cwnd / MSS)} seg`);
      if (r.event === "timeout") log("timeout", r.t, `retransmission timeout, RTO ${(r.rto * 1000).toFixed(0)} ms`);
      cwndChart.push(r.t, [r.cwnd / MSS, r.ssthresh == null ? null : r.ssthresh / MSS]);
      if (r.srtt) rttChart.push(r.t, [r.srtt * 1000, r.rtt ? r.rtt * 1000 : null]);
    }
    cwndChart.draw(); rttChart.draw();
    const s = d.stats;
    // state changes before the handshake finished are not in the trace stream
    if (s.state !== $("#conn-state").dataset.state) { setState(s.state); log("state", d.t, `→ ${s.state}`); }
    const dtk = d.t - lastT || 0.1;
    const inst = (s.bytes_acked - lastAcked) * 8 / dtk / 1e6;
    goodput = goodput ? goodput * 0.6 + inst * 0.4 : inst;
    lastAcked = s.bytes_acked; lastT = d.t;
    animateNumber($("#k-good"), goodput, 1);
    animateNumber($("#k-cwnd"), s.cwnd / MSS);
    $("#k-rtt").textContent = s.srtt ? (s.srtt * 1000).toFixed(0) : "–";
    $("#k-retx").textContent = s.retransmissions;
    if (s.retransmissions > lastRetx) flash($("#k-retx"));
    lastRetx = s.retransmissions;
    $("#k-prog").textContent = Math.min(100, (s.bytes_acked / size) * 100).toFixed(0);
    // the animation shows a scaled-down sample of the real packets
    const scale = 0.12;
    spawn("data", Math.min(40, Math.round(d.wire.out * scale) || (d.wire.out ? 1 : 0)));
    spawn("lost", Math.min(10, d.wire.lost + d.wire.queue_drop));
    spawn("ack", Math.min(40, Math.round(d.wire.out * scale * 0.9)));
    wire.queue = d.wire.queued ?? wire.queue;
  });
  const finish = () => {
    source.close(); source = null; wire.running = false;
    btn.disabled = false; btn.classList.remove("running"); btn.firstElementChild.textContent = "Start transfer";
  };
  source.addEventListener("done", e => {
    const r = JSON.parse(e.data);
    log("done", lastT, `done: ${r.goodput_mbps} Mbit/s, ${r.retransmissions} retransmissions, SHA-256 verified`);
    setState("CLOSED");
    finish();
  });
  source.addEventListener("error", e => {
    if (e.data) log("loss", lastT, "error: " + JSON.parse(e.data).message);
    finish();
  });
});

// ------------------------------------------------------------------ results
let resultsLoaded = false;
const FLOW_COLORS = { "rudp reno": "--data", "rudp cubic": "--violet", "rudp fixed": "--muted",
  "tcp reno": "--thresh", "tcp cubic": "--ack" };
async function loadResults() {
  if (resultsLoaded) return;
  resultsLoaded = true;
  const r = await (await fetch("/api/results")).json();

  if (r.matrix.length) {
    const keys = [...new Set(r.matrix.map(m => `${m.rtt_ms}|${m.loss}`))];
    const groups = keys.map(k => {
      const [rtt, loss] = k.split("|");
      const rows = r.matrix.filter(m => `${m.rtt_ms}|${m.loss}` === k);
      return {
        label: `${(+rtt).toFixed(0)} ms RTT\n${(+loss * 100).toFixed(1)}% loss`,
        bars: Object.keys(FLOW_COLORS).map(f => {
          const m = rows.find(x => `${x.impl} ${x.cc}` === f);
          return { value: m ? +m.goodput_mean : 0, err: m ? +m.ci95 : 0, color: FLOW_COLORS[f] };
        }),
      };
    });
    new BarChart($("#c-matrix")).set(groups);
    $("#matrix-legend").innerHTML = Object.entries(FLOW_COLORS)
      .map(([f, c]) => `<span style="--c:var(${c})">${f.replace("rudp", "rudp").replace("tcp", "Linux TCP")}</span>`).join("");
  } else {
    $("#matrix-legend").textContent = "No matrix yet: run python testbed/experiments.py matrix.";
  }

  const f = r.fairness;
  if (f.rudp_vs_rudp) {
    const d = f.rudp_vs_rudp;
    new LineChart($("#c-fair1"), { minY: 10, series: [
      { color: "--data", label: "flow A", fill: true, width: 2 }, { color: "--violet", label: "flow B (joins at 8 s)", width: 2 }] })
      .set([d.t.map((t, i) => [t, d.a[i]]), d.t.map((t, i) => [t, d.b[i] || null])]);
    $("#j-rr").textContent = `Jain ${d.jain.toFixed(3)} · ${d.share[0].toFixed(2)} / ${d.share[1].toFixed(2)} Mbit/s`;
  }
  if (f.rudp_vs_tcp) {
    const d = f.rudp_vs_tcp;
    new LineChart($("#c-fair2"), { minY: 10, series: [
      { color: "--violet", label: "rudp CUBIC", fill: true, width: 2 }, { color: "--ack", label: "Linux TCP CUBIC", width: 2 }] })
      .set([d.t.map((t, i) => [t, d.rudp[i] || null]), d.t.map((t, i) => [t, d.tcp[i] || null])]);
    $("#j-rt").textContent = `Jain ${d.jain.toFixed(3)} · ${d.share[0].toFixed(2)} / ${d.share[1].toFixed(2)} Mbit/s`;
  }
  for (const cc of ["reno", "cubic"]) {
    const tr = r.traces[cc];
    if (!tr || !tr.length) continue;
    new LineChart($("#c-tr-" + cc), { minY: 20, series: [
      { color: cc === "reno" ? "--data" : "--violet", label: "cwnd", fill: true, width: 1.6, step: true },
      { color: "--thresh", label: "ssthresh", dash: [6, 5], step: true }] })
      .set([tr.map(p => [p[0], p[1]]), tr.map(p => [p[0], p[2]])]);
  }
}

// ------------------------------------------------------------------ protocol
const FIELDS = [
  ["Version", 8, "Always 1. Anything else is dropped, so a future version can change the layout."],
  ["Flags", 8, "SYN 0x01, ACK 0x02, FIN 0x04, RST 0x08. Unknown bits make the segment invalid."],
  ["SACK count", 8, "How many 8-byte SACK blocks follow the header, from 0 to 4."],
  ["Reserved", 8, "Zero for now."],
  ["Connection ID", 32, "Random, picked by whoever connects. Together with the peer address it finds the connection."],
  ["Sequence number", 32, "Number of the first payload byte. Starts at a random ISN and wraps at 2³², compared with RFC 1982 arithmetic. SYN and FIN each take one number."],
  ["Acknowledgment number", 32, "The next byte this side expects: everything before it has arrived."],
  ["Receive window", 32, "Free bytes in the receive buffer. The sender never has more than this outstanding (flow control)."],
  ["Timestamp value", 32, "Sender's clock in milliseconds."],
  ["Timestamp echo reply", 32, "The peer's latest timestamp, sent back. now − echo = one RTT sample, even for retransmitted data."],
  ["Payload length", 16, "Bytes of data, up to the 1200-byte MSS."],
  ["Reserved", 16, "Zero for now."],
  ["Checksum (CRC-32)", 32, "Over the whole datagram with this field zeroed. Any single flipped bit is caught (there is a test that flips every one)."],
  ["SACK blocks", 32, "Up to four [left, right) ranges held above the ACK, the newest first. The sender resends only what is missing.", true],
  ["Payload", 32, "Up to 1200 bytes, so a full datagram fits the 1280-byte IPv6 minimum MTU.", true],
];
(function drawPacket() {
  let html = `<div class="bits">${Array.from({ length: 32 }, (_, i) => `<span>${i % 8 === 0 ? i : ""}</span>`).join("")}</div>`;
  FIELDS.forEach(([name, bits, , variable], i) => {
    html += `<div class="field${variable ? " var" : ""}" data-i="${i}" style="grid-column: span ${bits}">${name}</div>`;
  });
  $("#packet").innerHTML = html;
  const info = $("#field-info");
  document.querySelectorAll(".field").forEach(el => el.addEventListener("mouseenter", () => {
    document.querySelectorAll(".field").forEach(x => x.classList.toggle("on", x === el));
    const [name, bits, text, variable] = FIELDS[el.dataset.i];
    info.innerHTML = `<h3>${name}</h3><p class="size">${variable ? "variable" : bits + " bits"}</p><p>${text}</p>`;
  }));
})();

setState("CLOSED");
// #run starts a transfer as soon as the page opens (handy for demos and screenshots)
if (location.hash === "#run") { show("live"); setTimeout(() => $("#go").click(), 300); }
else show(location.hash.slice(1) || "live");
