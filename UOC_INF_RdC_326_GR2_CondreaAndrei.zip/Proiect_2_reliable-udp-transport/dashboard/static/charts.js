// Small canvas charts made for this page: live line charts and grouped bars.
// No library, so the dashboard keeps working offline.

const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();

function nice(range, ticks) {
  const raw = range / ticks, p = Math.pow(10, Math.floor(Math.log10(raw || 1))), f = raw / p;
  return (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * p;
}

function setup(canvas) {
  const dpr = window.devicePixelRatio || 1;
  // remember the height from the HTML: canvas.height gets multiplied by dpr below
  canvas._h = canvas._h || canvas.getAttribute("height") * 1;
  const w = canvas.clientWidth, h = canvas._h;
  if (canvas._w !== w || canvas._dpr !== dpr) {
    canvas.width = w * dpr; canvas.height = h * dpr; canvas.style.height = h + "px";
    canvas._w = w; canvas._dpr = dpr;
  }
  const g = canvas.getContext("2d");
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, w, h);
  return { g, w, h };
}

function axes(g, box, xMax, yMax, xUnit) {
  const { l, t, w, h } = box;
  g.font = "11px 'JetBrains Mono', monospace";
  g.fillStyle = css("--muted");
  g.strokeStyle = css("--line-soft");
  g.lineWidth = 1;
  const ys = nice(yMax, 4);
  for (let y = 0; y <= yMax + 1e-9; y += ys) {
    const py = t + h - (y / yMax) * h;
    g.beginPath(); g.moveTo(l, py); g.lineTo(l + w, py); g.stroke();
    g.textAlign = "right"; g.fillText(+y.toFixed(2), l - 8, py + 4);
  }
  const xs = nice(xMax, Math.max(3, w / 110));
  for (let x = 0; x <= xMax + 1e-9; x += xs) {
    const px = l + (x / xMax) * w;
    g.textAlign = "center"; g.fillText(+x.toFixed(1) + (xUnit || ""), px, t + h + 16);
  }
}

class LineChart {
  constructor(canvas, opts) {
    this.c = canvas; this.o = opts; this.data = opts.series.map(() => []);
    window.addEventListener("resize", () => this.draw());
  }
  reset() { this.data = this.o.series.map(() => []); this.draw(); }
  set(data) { this.data = data; this.draw(); }
  push(x, values) { values.forEach((v, i) => this.data[i].push([x, v])); }
  draw() {
    const { g, w, h } = setup(this.c);
    const box = { l: 44, t: 10, w: w - 56, h: h - 34 };
    const all = this.data.flat().filter(p => p[1] != null);
    const xMax = Math.max(this.o.minX || 1, ...all.map(p => p[0]));
    const yMax = Math.max(this.o.minY || 1, ...all.map(p => p[1])) * 1.12;
    axes(g, box, xMax, yMax, this.o.xUnit || "s");
    const X = x => box.l + (x / xMax) * box.w, Y = y => box.t + box.h - (y / yMax) * box.h;

    this.o.series.forEach((s, i) => {
      const pts = this.data[i].filter(p => p[1] != null);
      if (pts.length < 2) return;
      const color = css(s.color);
      g.beginPath();
      pts.forEach(([x, y], k) => {
        if (k && s.step) g.lineTo(X(x), Y(pts[k - 1][1]));
        k ? g.lineTo(X(x), Y(y)) : g.moveTo(X(x), Y(y));
      });
      if (s.fill) {
        const grad = g.createLinearGradient(0, box.t, 0, box.t + box.h);
        grad.addColorStop(0, color + "55"); grad.addColorStop(1, color + "00");
        g.save();
        g.lineTo(X(pts[pts.length - 1][0]), box.t + box.h); g.lineTo(X(pts[0][0]), box.t + box.h);
        g.fillStyle = grad; g.fill(); g.restore();
        g.beginPath();
        pts.forEach(([x, y], k) => {
          if (k && s.step) g.lineTo(X(x), Y(pts[k - 1][1]));
          k ? g.lineTo(X(x), Y(y)) : g.moveTo(X(x), Y(y));
        });
      }
      g.strokeStyle = color; g.lineWidth = s.width || 1.8; g.setLineDash(s.dash || []);
      if (s.glow) { g.shadowColor = color; g.shadowBlur = 10; }
      g.stroke(); g.shadowBlur = 0; g.setLineDash([]);
      // a bright dot on the newest point
      if (s.head) {
        const [x, y] = pts[pts.length - 1];
        g.fillStyle = color; g.beginPath(); g.arc(X(x), Y(y), 3.5, 0, 7); g.fill();
      }
    });
    // legend
    let lx = box.l + 8;
    g.font = "12px Inter, sans-serif"; g.textAlign = "left";
    this.o.series.forEach(s => {
      if (!s.label) return;
      g.fillStyle = css(s.color); g.fillRect(lx, box.t + 6, 14, 3);
      g.fillStyle = css("--text"); g.fillText(s.label, lx + 20, box.t + 11);
      lx += g.measureText(s.label).width + 40;
    });
  }
}

class BarChart {
  // groups: [{label, bars: [{value, err, color}]}]
  constructor(canvas) { this.c = canvas; window.addEventListener("resize", () => this.draw()); }
  set(groups) { this.groups = groups; this.t0 = performance.now(); this.animate(); }
  animate() {
    const k = Math.min(1, (performance.now() - this.t0) / 700);
    this.draw(1 - Math.pow(1 - k, 3));
    if (k < 1) requestAnimationFrame(() => this.animate());
  }
  draw(k = 1) {
    if (!this.groups) return;
    const { g, w, h } = setup(this.c);
    const box = { l: 44, t: 12, w: w - 56, h: h - 52 };
    const yMax = Math.max(1, ...this.groups.flatMap(gr => gr.bars.map(b => b.value + (b.err || 0)))) * 1.1;
    g.font = "11px 'JetBrains Mono', monospace"; g.fillStyle = css("--muted"); g.strokeStyle = css("--line-soft");
    const ys = nice(yMax, 4);
    for (let y = 0; y <= yMax; y += ys) {
      const py = box.t + box.h - (y / yMax) * box.h;
      g.beginPath(); g.moveTo(box.l, py); g.lineTo(box.l + box.w, py); g.stroke();
      g.textAlign = "right"; g.fillText(+y.toFixed(1), box.l - 8, py + 4);
    }
    const gw = box.w / this.groups.length;
    this.groups.forEach((gr, i) => {
      const n = gr.bars.length, bw = Math.min(26, (gw - 24) / n);
      const x0 = box.l + i * gw + (gw - bw * n) / 2;
      gr.bars.forEach((b, j) => {
        const x = x0 + j * bw, v = b.value * k;
        const py = box.t + box.h - (v / yMax) * box.h;
        const color = css(b.color);
        const grad = g.createLinearGradient(0, py, 0, box.t + box.h);
        grad.addColorStop(0, color); grad.addColorStop(1, color + "55");
        g.fillStyle = grad;
        g.beginPath(); g.roundRect ? g.roundRect(x + 2, py, bw - 4, box.t + box.h - py, [4, 4, 0, 0]) : g.rect(x + 2, py, bw - 4, box.t + box.h - py);
        g.fill();
        if (b.err && k === 1) {
          const e1 = box.t + box.h - ((b.value + b.err) / yMax) * box.h, e2 = box.t + box.h - ((b.value - b.err) / yMax) * box.h;
          g.strokeStyle = css("--text"); g.lineWidth = 1;
          g.beginPath(); g.moveTo(x + bw / 2, e1); g.lineTo(x + bw / 2, e2);
          g.moveTo(x + bw / 2 - 4, e1); g.lineTo(x + bw / 2 + 4, e1);
          g.moveTo(x + bw / 2 - 4, e2); g.lineTo(x + bw / 2 + 4, e2); g.stroke();
        }
      });
      g.fillStyle = css("--muted"); g.textAlign = "center";
      gr.label.split("\n").forEach((line, li) => g.fillText(line, box.l + i * gw + gw / 2, box.t + box.h + 16 + li * 14));
    });
  }
}
