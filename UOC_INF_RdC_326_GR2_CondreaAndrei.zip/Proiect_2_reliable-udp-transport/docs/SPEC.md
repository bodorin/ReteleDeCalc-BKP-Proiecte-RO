# RUDP/1: a reliable transport over UDP

Status: implemented in `rudp/`, version 1.

The key words MUST, SHOULD and MAY are used as in RFC 2119.

## 1. Overview

RUDP/1 gives an application an ordered, reliable byte stream between two hosts,
carried in UDP datagrams. It borrows its machinery from TCP:

- a three-way handshake and a FIN-based teardown with the TCP state machine;
- byte sequence numbers with serial-number arithmetic (RFC 1982), so they wrap safely;
- cumulative acknowledgements plus selective acknowledgements (SACK, after RFC 2018);
- a Selective Repeat sender that retransmits only what the receiver lacks;
- RTT measurement with timestamps (after RFC 7323) and the RTO of RFC 6298;
- loss recovery with fast retransmit and SACK-based recovery (after RFC 6675);
- pluggable congestion control: a fixed window, Reno/NewReno (RFC 5681, RFC 6582)
  and CUBIC (RFC 9438);
- flow control through an advertised receive window, with zero-window probing.

It runs entirely in user space, as QUIC does.

## 2. Packet format

Every datagram carries exactly one segment. All fields are in network byte order.

```
 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+---------------+---------------+---------------+---------------+
|    Version    |     Flags     |  SACK Count   |   Reserved    |
+---------------+---------------+---------------+---------------+
|                         Connection ID                         |
+---------------------------------------------------------------+
|                        Sequence Number                        |
+---------------------------------------------------------------+
|                     Acknowledgment Number                     |
+---------------------------------------------------------------+
|                         Receive Window                        |
+---------------------------------------------------------------+
|                        Timestamp Value                        |
+---------------------------------------------------------------+
|                     Timestamp Echo Reply                      |
+-------------------------------+-------------------------------+
|        Payload Length         |           Reserved            |
+-------------------------------+-------------------------------+
|                       Checksum (CRC-32)                       |
+---------------------------------------------------------------+
|        SACK blocks: SACK Count x (Left Edge, Right Edge)      |
+---------------------------------------------------------------+
|                            Payload                            |
+---------------------------------------------------------------+
```

| Field | Size | Meaning |
|---|---|---|
| Version | 8 bits | MUST be 1. Segments with any other version are dropped. |
| Flags | 8 bits | `SYN` 0x01, `ACK` 0x02, `FIN` 0x04, `RST` 0x08. Other bits MUST be zero. |
| SACK Count | 8 bits | Number of SACK blocks that follow the header, 0 to 4. |
| Connection ID | 32 bits | Chosen at random by the initiator; identifies the connection on both sides. |
| Sequence Number | 32 bits | Sequence number of the first payload byte. SYN and FIN each occupy one number. |
| Acknowledgment Number | 32 bits | Next sequence number the sender of this segment expects. Valid when `ACK` is set. |
| Receive Window | 32 bits | Free space in the sender's receive buffer, in bytes. |
| Timestamp Value | 32 bits | Sender's clock in milliseconds, modulo 2^32. |
| Timestamp Echo Reply | 32 bits | The Timestamp Value of the most recent segment received from the peer. |
| Payload Length | 16 bits | Bytes of payload. At most the MSS. |
| Checksum | 32 bits | CRC-32 (IEEE 802.3) over the whole datagram, computed with this field set to zero. |
| SACK block | 64 bits each | `[Left Edge, Right Edge)`: a contiguous range the receiver holds above the cumulative ACK. |

The fixed header is 36 bytes. The maximum segment size (MSS) is 1200 bytes of
payload, so a full datagram with four SACK blocks is 1268 bytes and fits the
1280-byte IPv6 minimum MTU without fragmentation.

A receiver MUST silently discard a datagram that is shorter than 36 bytes, whose
Payload Length or SACK Count does not match its size, or whose checksum fails.

## 3. Connection identification

A connection is identified by the pair (peer address, Connection ID). The
initiator picks the Connection ID uniformly at random. Each side picks its
initial sequence number (ISN) uniformly at random from the 32-bit space.

## 4. Connection states

The state machine is TCP's (RFC 9293, section 3.3.2):

```
                              +---------+
                              | CLOSED  |
                              +---------+
               listen() |                     | connect() / send SYN
                        v                     v
                  +---------+           +----------+
                  | LISTEN  |           | SYN_SENT |
                  +---------+           +----------+
       recv SYN / send SYN+ACK |              | recv SYN+ACK / send ACK
                        v                     |
                  +----------+                |
                  | SYN_RCVD |                |
                  +----------+                |
     recv ACK of SYN |                        |
                        v                     v
                        +--------------------+
                        |    ESTABLISHED     |
                        +--------------------+
          close() / send FIN |              | recv FIN / send ACK
                     v                      v
             +------------+          +------------+
             | FIN_WAIT_1 |          | CLOSE_WAIT |
             +------------+          +------------+
  recv ACK of FIN |   | recv FIN / ACK    | close() / send FIN
                  v   v                   v
     +------------+  +---------+    +----------+
     | FIN_WAIT_2 |  | CLOSING |    | LAST_ACK |
     +------------+  +---------+    +----------+
   recv FIN / ACK |       | recv ACK of FIN | recv ACK of FIN
                  v       v                 v
               +-----------+          +---------+
               | TIME_WAIT |--------->| CLOSED  |
               +-----------+  2 x MSL +---------+
```

A listener answers each new SYN with SYN+ACK and keeps the connection in SYN_RCVD
until the ACK of its SYN arrives (with or without data). It MUST limit the number
of half-open connections (`backlog`, default 64) and drop SYNs beyond it.

Lost SYN, SYN+ACK and FIN segments are retransmitted on the RTO timer, at most
6 times, after which the connection is aborted with a timeout error.

`RST` aborts a connection at once. An endpoint MUST answer a non-SYN segment for
an unknown connection with `RST`, and MUST NOT answer an `RST` with an `RST`.

## 5. Data transfer

### 5.1 Receiver

The receiver keeps `RCV.NXT`, the next byte it expects. In-order data is handed to
the application at once; data beyond `RCV.NXT` is kept in an out-of-order buffer,
as long as it fits in the receive window. Duplicate data is discarded.

Every segment that carries data or a FIN MUST be acknowledged immediately with
`ACK = RCV.NXT`. When the out-of-order buffer is not empty, the ACK carries up to
four SACK blocks, the block containing the most recently received segment first
(RFC 2018, section 4).

The Receive Window is the free space in the receive buffer: its capacity minus the
bytes held for the application and in the out-of-order buffer.

### 5.2 Sender

The sender keeps `SND.UNA` (oldest unacknowledged byte) and `SND.NXT` (next new
byte). It MAY send new data while

```
pipe + MSS <= min(cwnd, rwnd)
```

where `pipe` is the number of bytes in flight: sent, not acknowledged, not SACKed
and not marked lost (RFC 6675, section 4). Segments are at most one MSS long.

An ACK is *new* if it advances `SND.UNA`. SACK blocks mark the segments they cover
as delivered; those segments are never retransmitted.

### 5.3 Loss detection

A segment is considered lost when any of the following holds:

1. at least three segments sent after it have been SACKed (`DupThresh` = 3);
2. three duplicate ACKs arrived and it is the segment at `SND.UNA`;
3. the retransmission timer expired.

The first two trigger *fast retransmit* and *recovery*; the third triggers a
*timeout*.

### 5.4 Recovery

On entering recovery the sender records `RecoveryPoint = SND.NXT`, notifies the
congestion controller once, and retransmits lost segments ahead of new data,
each at most once per recovery episode, as long as `pipe` allows. Recovery ends
when `SND.UNA` passes `RecoveryPoint`. A further loss detected during recovery
does not reduce the window again.

### 5.5 Retransmission timer

RTT is measured from the timestamp echo of each new ACK: `RTT = now - TSecr`.
Because the echoed value belongs to the segment that triggered the ACK, samples
are valid even for retransmitted data, which removes the ambiguity that Karn's
algorithm works around.

`SRTT`, `RTTVAR` and `RTO` follow RFC 6298 with `alpha = 1/8`, `beta = 1/4`,
`K = 4`, an initial RTO of 1 s, a minimum of 200 ms and a maximum of 60 s.
The timer runs whenever data is in flight and is restarted on every new ACK.
When it expires, all unacknowledged segments that are not SACKed are marked lost,
the congestion controller is told, and the RTO doubles.

### 5.6 Flow control and window probing

If the peer advertises a zero window while the sender has data, the sender starts
a persist timer at the current RTO. On expiry it sends a one-byte probe and doubles
the persist interval, until a non-zero window is advertised.

## 6. Congestion control

The controller owns `cwnd` and `ssthresh`, in bytes, and is called on every new ACK,
at the start of a recovery episode and on a timeout. The initial window is
`10 x MSS` (RFC 6928).

| Algorithm | New ACK | Loss (recovery) | Timeout |
|---|---|---|---|
| `fixed` | none | none | none |
| `reno` | slow start: `cwnd += min(acked, 2 MSS)` below `ssthresh`; otherwise `cwnd += MSS * acked / cwnd` | `ssthresh = cwnd = max(pipe / 2, 2 MSS)` | `ssthresh = max(pipe / 2, 2 MSS)`, `cwnd = 1 MSS` |
| `cubic` | `cwnd` follows `W(t) = C (t - K)^3 + W_max`, never below the Reno-friendly estimate | `W_max = cwnd`, `cwnd = ssthresh = 0.7 cwnd` (with fast convergence) | as Reno, and `W_max` is reset |

CUBIC uses `C = 0.4` and `beta = 0.7` as in RFC 9438.

## 7. Error handling summary

| Event | Reaction |
|---|---|
| Corrupted or malformed datagram | Dropped silently |
| Segment for an unknown connection | `RST`, unless it is itself an `RST` or a `SYN` to a listener |
| `RST` received | Connection closed, pending reads and writes fail |
| No answer to SYN / FIN after 6 retransmissions | Connection aborted with a timeout |
| No progress on data after 10 consecutive timeouts | Connection aborted with a timeout |
| Data outside the receive window | Dropped and acknowledged with the current ACK |

## 8. Security considerations

RUDP/1 provides no confidentiality or authentication; it is meant to run under an
encrypting layer, as TCP runs under TLS. The random Connection ID and ISN make
blind injection harder, since an off-path attacker has to guess 64 random bits to
inject a segment that is accepted, but an on-path attacker can read, modify or
reset the connection. The half-open limit bounds the memory a SYN flood can take,
but does not stop it; SYN cookies would. These points are discussed in the report.
