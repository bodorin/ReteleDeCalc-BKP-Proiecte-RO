<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/assets/header-dark.svg" />
  <source media="(prefers-color-scheme: light)" srcset="docs/assets/header-light.svg" />
  <img alt="rudp: a byte stream where segment 3 is lost, segments 4 to 7 are covered by a SACK block, and only segment 3 is resent" src="docs/assets/header-dark.svg" width="100%" />
</picture>

<p><strong>A reliable, congestion-controlled byte stream over UDP, built from the TCP RFCs<br />
and measured against the Linux kernel's own TCP on a real netem path.</strong></p>

<p>
  <a href="#quick-start">Quick start</a>
  &nbsp;·&nbsp;
  <a href="#results">Results</a>
  &nbsp;·&nbsp;
  <a href="docs/SPEC.md">Protocol spec</a>
  &nbsp;·&nbsp;
  <a href="#the-testbed">Testbed</a>
  &nbsp;·&nbsp;
  <a href="docs/report/">Report (RO)</a>
</p>

<p>
  <a href="https://github.com/AndrewTechTips/reliable-udp-transport/actions/workflows/tests.yml"><img src="https://github.com/AndrewTechTips/reliable-udp-transport/actions/workflows/tests.yml/badge.svg" alt="Tests" /></a>
  <img src="https://img.shields.io/badge/python-3.10%2B-3776AB?logo=python&logoColor=white" alt="Python 3.10+" />
  <img src="https://img.shields.io/badge/dependencies-none-2ea44f" alt="No runtime dependencies" />
  <img src="https://img.shields.io/badge/testbed-Docker%20%2B%20netem-2496ED?logo=docker&logoColor=white" alt="Docker and netem testbed" />
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-blue" alt="MIT licence" /></a>
</p>

</div>

<p align="center">
  <img src="docs/assets/dashboard-live.jpg" width="900" alt="The live dashboard during a Reno transfer: packets streaming between sender and receiver through a bottleneck queue, goodput, cwnd and smoothed RTT counters, the congestion window sawtooth and the RTT rising as the queue fills, and the connection state machine with ESTABLISHED lit" />
</p>

rudp is what TCP looks like when you write it yourself, in user space, the way QUIC does: a
three-way handshake, Selective Repeat with SACK, RTT from echoed timestamps and the RFC 6298
timer, loss recovery after RFC 6675, flow control, and Reno or CUBIC deciding how fast to go.
About 1,700 lines of Python with no dependencies, an API that looks like sockets, and every
rule traceable to a line in [the spec](docs/SPEC.md).

It is measured the honest way: two Linux containers, a bottleneck made by `netem` in the
kernel, and Linux's own TCP on the same path through `iperf3`.

## Highlights

- **The whole TCP lifecycle.** SYN, SYN-ACK, ACK; FIN in both directions; TIME_WAIT; RST for
  strangers. Random ISNs and connection IDs, 32-bit sequence numbers that wrap safely
  (RFC 1982), and many connections on one port.
- **Selective Repeat, for real.** The receiver sends up to four SACK blocks, the sender keeps a
  scoreboard and marks a segment lost once three later ones are SACKed. There is a test that
  drops exactly one segment and checks that exactly one retransmission follows.
- **Timers by the book.** RFC 6298 RTO with backoff; RTT samples from timestamp echoes, so even
  retransmitted data gives a valid sample. Zero windows are probed on a persist timer.
- **Three congestion controllers.** A fixed window, Reno with byte counting, and CUBIC with the
  Reno-friendly region and fast convergence (RFC 9438).
- **It shows its work.** `--trace` writes every cwnd, ssthresh, pipe and RTT change; the
  dashboard draws them live, with the packets, the queue and the state machine.
- **Measured, not simulated.** A Docker testbed with netem, TSO/GSO off so Linux TCP meets the
  bottleneck packet by packet too, and every experiment repeated with 95% intervals.

## Quick start

```bash
git clone https://github.com/AndrewTechTips/reliable-udp-transport.git
cd reliable-udp-transport
make install                 # .venv with pytest and matplotlib
make test                    # 33 tests
make dashboard               # http://localhost:8080
```

Move a file between two machines:

```bash
rudp recv --listen 0.0.0.0:9000 --out received/          # on the receiver
rudp send photo.jpg 192.168.1.20:9000 --cc cubic          # on the sender
```

The receiver answers with the SHA-256 of what it got, so the sender knows the copy is exact.
`rudp bench host:port --size 20M --json` sends generated data and prints goodput,
retransmissions and RTT; add `--trace trace.csv` to keep the congestion window's history.

Or use the library:

```python
import asyncio, rudp

async def main():
    listener = await rudp.listen("0.0.0.0", 9000)
    conn = await rudp.connect("127.0.0.1", 9000, options=rudp.Options(cc="cubic"))
    server = await listener.accept()
    await conn.send(b"hello")
    print(await server.recv())
    await conn.close()

asyncio.run(main())
```

## Results

Numbers from the Docker testbed: a 10 Mbit/s bottleneck with a 50-packet netem queue.
`make experiments` reproduces all of them; the raw runs are in [`results/`](results/).

<p align="center">
  <img src="docs/figures/goodput_matrix.png" width="780" alt="Grouped bars of goodput for rudp Reno, CUBIC and fixed window and Linux TCP Reno and CUBIC at 20 and 80 ms RTT and 0, 0.5 and 2% loss" />
</p>

| Goodput, Mbit/s | 20 ms, 0% | 20 ms, 0.5% | 20 ms, 2% | 80 ms, 0% | 80 ms, 0.5% | 80 ms, 2% |
|---|---:|---:|---:|---:|---:|---:|
| rudp Reno | 9.29 | 7.79 | 3.76 | 5.73 | 2.26 | 1.00 |
| rudp CUBIC | 9.29 | 7.62 | 3.59 | 5.90 | 2.35 | 0.99 |
| rudp fixed window (32) | 9.33 | 9.32 | 9.27 | 3.49 | 3.53 | 3.33 |
| Linux TCP Reno | 8.32 | 8.32 | 5.09 | 8.20 | 3.58 | 1.40 |
| Linux TCP CUBIC | 8.32 | 8.33 | 4.81 | 8.20 | 4.49 | 1.45 |

Five interleaved 4 MB runs per cell; the 95% intervals are in
[`results/matrix_summary.csv`](results/matrix_summary.csv). What I read from it:

- **Short transfers flatter rudp on a short path.** With 4 MB at 20 ms, rudp fills the link
  (9.29 Mbit/s) while `iperf3` reports 8.32 for TCP. That gap is iperf3's timing of a short run
  (its last second carries the final ACKs at 2 Mbit/s). Run for 20 s, Linux TCP Reno does
  9.53 Mbit/s and a 24 MB rudp Reno transfer 9.36: a dead heat.
- **On a long path the kernel has an edge user space cannot match.** At 80 ms a long rudp
  transfer gets 7.25 Mbit/s against 9.38 for TCP. `tc -s qdisc` shows every rudp loss in the netem
  queue, and none for TCP: the kernel's TCP Small Queues hears that the local queue is full and
  slows down without losing a packet, while anything over UDP (QUIC included) learns of it one
  RTT later, from SACK, and halves below the bandwidth-delay product. Short transfers add
  slow-start overshoot on top, since rudp has no HyStart.
- **Under random loss Linux TCP stays ahead**, thanks to RACK and PRR. Both fall as 1/(RTT·√p),
  as the Mathis formula says they should.
- **The fixed window "wins" at 2% loss** (9.27 Mbit/s) because it never backs off.
  On a shared link that is exactly the behaviour congestion control exists to prevent.

<p align="center">
  <img src="docs/figures/cwnd_traces.png" width="780" alt="Congestion window over 28 seconds: Reno saws between about 35 and 71 segments; CUBIC climbs fast after each cut and flattens near its previous maximum" />
</p>

**The congestion window, through netem.** Reno saws between about 35 and 71 segments. CUBIC
does what RFC 9438 says it should: a fast climb after each cut to 70%, then a plateau around the
window where it last lost packets.

<p align="center">
  <img src="docs/figures/rtt_trace.png" width="780" alt="Smoothed RTT rising from 42 to 71 ms and dropping back, in step with the sawtooth" />
</p>

**Bufferbloat, measured.** The base RTT is 40 ms; rudp sees up to about 71 ms, the time its own
packets spend in the netem queue, and it drops back after every halving.

<p align="center">
  <img src="docs/figures/fairness.png" width="780" alt="Top: two rudp Reno flows split the link about evenly after the second joins. Bottom: rudp CUBIC and Linux TCP CUBIC share the link" />
</p>

**Fair to itself and to Linux.** Two rudp Reno flows settle at 4.73 and 4.57 Mbit/s
(Jain index 1.000). rudp CUBIC against the kernel's TCP CUBIC gets 4.89 against
4.58 Mbit/s (Jain 0.999): it neither starves TCP nor gets starved.

## The testbed

```
 host:  testbed/experiments.py ──docker compose exec──┐
                                                      ▼
 ┌──────────────── sender 10.77.0.10 ────────────────┐      ┌──────────── receiver 10.77.0.20 ───────────┐
 │ rudp bench   /   iperf3 -c -C reno|cubic           │ ───► │ rudp recv   /   iperf3 -s                  │
 │ netem: 10 Mbit/s, 50-packet queue, RTT/2, loss     │ ◄─── │ netem: RTT/2                               │
 └────────────────────────────────────────────────────┘      └────────────────────────────────────────────┘
```

```bash
make lab-up                                   # build and start both containers
cd testbed && python3 experiments.py traces   # cwnd traces (a few minutes)
python3 experiments.py fairness               # rudp vs rudp, rudp vs Linux TCP
python3 experiments.py matrix --reps 5        # the full grid (about an hour)
python3 experiments.py captures               # pcaps of rudp and TCP, decoded by tshark
make figures                                  # redraw docs/figures
```

One detail mattered more than any other: Linux TCP hands the NIC 64 KB super-packets (TSO and
GSO), and netem rate-limits per packet, so with offloads on TCP seemed to beat the link itself.
`lab.py` turns them off on both containers before every run.

## Seeing it in Wireshark

[`tools/wireshark/rudp.lua`](tools/wireshark/rudp.lua) is a dissector for RUDP/1: header
fields, flags and SACK blocks shown relative to the ACK. Wireshark already has a Cisco
protocol called `rudp`, so the filters are `rudp1.*`, e.g. `rudp1.sack_count > 0`.
[`results/captures/`](results/captures/) holds a rudp and a TCP transfer over the same lossy
path. In the rudp one you can follow a whole connection:

```
 1  0.000  S→R  [SYN] seq=2712004780 ack=0
 2  0.024  R→S  [SYN,ACK] seq=2764046555 ack=2712004781
42  0.122  R→S  [ACK] ack=2712015616 SACK [+1200,+2400)      a segment went missing
45  0.122  R→S  [ACK] ack=2712015616 SACK [+1200,+6000)      three more arrived after it
62  0.149  S→R  [ACK] seq=2712015616 len=1200                only the hole is resent
71  0.170  R→S  [ACK] ack=2712040816                         the ACK jumps 21 segments
674 1.126  R→S  [ACK] len=32                                 the receiver's SHA-256
676 1.159  S→R  [ACK,FIN]  ...  679  S→R  [ACK]              both sides close
```

## How it is built

<p align="center">
  <img src="docs/figures/arch_components.png" width="560" alt="Component diagram: the application talks to Connection, which holds the state machine, the SACK scoreboard sender, the reassembling receiver, the RTT estimator and the congestion controller; Connection sits on Endpoint, which demultiplexes datagrams by address and connection ID over one UDP socket" />
</p>

| Path | What is there |
|---|---|
| [`rudp/wire.py`](rudp/wire.py) | the 36-byte header, CRC-32, SACK blocks |
| [`rudp/connection.py`](rudp/connection.py) | state machine, sender, receiver, recovery, timers |
| [`rudp/endpoint.py`](rudp/endpoint.py) | the UDP socket, demultiplexing, `listen` and `connect` |
| [`rudp/cc.py`](rudp/cc.py) | fixed window, Reno, CUBIC |
| [`rudp/rtt.py`](rudp/rtt.py) · [`seqnum.py`](rudp/seqnum.py) · [`ranges.py`](rudp/ranges.py) | RFC 6298, RFC 1982 and the range set behind SACK |
| [`rudp/transfer.py`](rudp/transfer.py) · [`__main__.py`](rudp/__main__.py) | file transfer and the `rudp` command |
| [`rudp/impair.py`](rudp/impair.py) | a lossy UDP relay, so the tests run on any OS |
| [`dashboard/`](dashboard/) | the live dashboard: asyncio HTTP and Server-Sent Events, canvas charts |
| [`testbed/`](testbed/) | Dockerfile, compose file and the experiment runner |
| [`tests/`](tests/) | 33 unit and integration tests |

Inside a connection every byte has a plain integer offset; wrapping 32-bit sequence numbers
exist only on the wire. That one decision keeps the window, the scoreboard and reassembly free
of modular comparisons.

## Limits

It is Python, so it does tens of Mbit/s, not gigabits. There is no encryption: run it under a
secure layer as TCP runs under TLS. It has no HyStart, pacing or RACK, which is why it overshoots
in slow start where Linux does not. The report goes through these one by one, along with a
threat model.

## Background

This was my C01 project for the Computer Networks course (3rd year, Computer Science). The
Romanian write-up in [`docs/report/`](docs/report/) has the design, pseudocode, every experiment
and the security analysis. Its little sibling,
[tcp-congestion-lab](https://github.com/AndrewTechTips/tcp-congestion-lab), shows the same
mechanisms on a simulated link.

## Licence

[MIT](LICENSE)
